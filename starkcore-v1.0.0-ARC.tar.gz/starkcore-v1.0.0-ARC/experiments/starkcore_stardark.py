#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
StarkCore — STARDARK Engine: Suite de Pruebas Adversariales (Vacuna del Sistema)
Autor: Luis Alberto Burciaga Miker
Ubicación: El Rosario / Ensenada, Baja California, México
Contexto: "Solo curiosiaba" — Rompiendo el espacio de fases intencionalmente.
"""

import hashlib
import json
import os
import sys
import time

def calcular_sha256(texto):
    return hashlib.sha256(texto.encode('utf-8')).hexdigest()

def simular_firma_clave(hash_datos, clave_autoridad):
    return calcular_sha256(f"{hash_datos}::SIGNED_BY_{clave_autoridad}")

class EntornoEjecucion:
    def __init__(self, tipo_nodo, attestation_hardware):
        self.contexto = {"nodo": tipo_nodo, "attestation": attestation_hardware}
    def serializar(self):
        return json.dumps(self.contexto, sort_keys=True, separators=(',', ':'))

class WorkloadStardark:
    def __init__(self, i_c_objeto, entorno, evidencia_ejecucion):
        self.i_c = i_c_objeto
        self.entorno = entorno
        self.evidencia = evidencia_ejecucion

    def calcular_i_e(self):
        str_combinado = f"{self.i_c}{self.entorno.serializar()}{self.evidencia}"
        return calcular_sha256(str_combinado)

class CertificadoTransicion:
    @staticmethod
    def generar(i_e_origen, i_e_destino, politica, clave_autoridad):
        hash_transicion = calcular_sha256(f"{i_e_origen}{i_e_destino}{politica}")
        return simular_firma_clave(hash_transicion, clave_autoridad)

def auditar_sistema_stardark(i_c_esperado, w_origen, w_destino, certificado, politica_esperada, clave_autoridad):
    # 1. Verificar invarianza del objeto (I_C)
    if w_origen.i_c != w_destino.i_c or w_origen.i_c != i_c_esperado:
        return "RECHAZADO: Corrupción/Mutación de Carga (Ataque 1)"
        
    i_e_ori = w_origen.calcular_i_e()
    i_e_des = w_destino.calcular_i_e()
    
    # 2. Reconstruir y verificar la firma del certificado de transición
    t_reconstruido = CertificadoTransicion.generar(i_e_ori, i_e_des, politica_esperada, clave_autoridad)
    
    if t_reconstruido != certificado:
        return "RECHAZADO: Violación de Evidencia o Certificado Falso (Ataques 2 y 3)"
        
    return "ACEPTADO: Transición Autorizada"

if __name__ == "__main__":
    print("====================================================================")
    print("=== STARDARK ADVERSARIAL TEST: EJECUTANDO SIMULACIÓN DE ATAQUES ===")
    print("====================================================================")
    
    # Inyección Segura de la Clave: Si no existe en el CI, cae a un entorno mock controlado
    clave_stardark = os.environ.get("STARDARK_SIGNING_KEY", "MOCK_PROTECTED_KEY_2026_SANDBOX")
    
    i_c_base = "586a171afa714fe0d6f72fae5e2351407f2b49119e0f6221513ddd73efda6cf1"
    politica = "alta_confianza_miker"
    
    # Base Genuina de Control
    entorno_local = EntornoEjecucion("celular_userland", "attestation_arm64_ok_01")
    w_local = WorkloadStardark(i_c_base, entorno_local, "evidencia_firmada_kernel_ok")
    i_e_local = w_local.calcular_i_e()
    
    entorno_nube = EntornoEjecucion("servidor_nube", "attestation_xeon_secure_02")
    w_nube_valida = WorkloadStardark(i_c_base, entorno_nube, "evidencia_firmada_kernel_ok")
    i_e_nube_valida = w_nube_valida.calcular_i_e()
    
    t_valido = CertificadoTransicion.generar(i_e_local, i_e_nube_valida, politica, clave_stardark)
    
    # ----------------------------------------------------------------
    # ATAQUE 1: Mutación del Workload (Alterar el I_C base del objeto)
    # ----------------------------------------------------------------
    w_nube_mutado = WorkloadStardark("HASH_MUTADO_ILEGALMENTE_9999", entorno_nube, "evidencia_firmada_kernel_ok")
    res_1 = auditar_sistema_stardark(i_c_base, w_local, w_nube_mutado, t_valido, politica, clave_stardark)
    print(f"  -> Vector 1 (Mutar Carga I_C):          {res_1}")
    assert "RECHAZADO" in res_1

    # ----------------------------------------------------------------
    # ATAQUE 2: Falsificación de la Evidencia de Ejecución (V)
    # ----------------------------------------------------------------
    w_nube_evidencia_falsa = WorkloadStardark(i_c_base, entorno_nube, "evidencia_INYECTADA_PROXIED_ERR")
    res_2 = auditar_sistema_stardark(i_c_base, w_local, w_nube_evidencia_falsa, t_valido, politica, clave_stardark)
    print(f"  -> Vector 2 (Falsificar Evidencia V):   {res_2}")
    assert "RECHAZADO" in res_2

    # ----------------------------------------------------------------
    # ATAQUE 3: Certificado de Transición Inválido (Token de Salto Falso)
    # ----------------------------------------------------------------
    t_falso_atacante = "hash_de_un_token_de_salto_no_autorizado_o_mal_firmado"
    res_3 = auditar_sistema_stardark(i_c_base, w_local, w_nube_valida, t_falso_atacante, politica, clave_stardark)
    print(f"  -> Vector 3 (Certificado T Falso):      {res_3}")
    assert "RECHAZADO" in res_3

    print("\n✅ VACUNA EXITOSA: El motor STARDARK rechazó los 3 vectores de forma contundente.")
    
    # Generar el reporte encadenado analítico
    attestation_report = {
        "commit_hash": os.environ.get("CI_COMMIT_SHA", "8fb9beb_diario_criptografico"),
        "rust_version": "1.75.0-slim",
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}-slim",
        "test_results": {"status": "SUCCESS", "adversarial_vaccine": "PASSED"},
        "axioma_validado": "Axioma XIV — Identidad Verificable Bajo Transformación",
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "certificado_t": t_valido,
        "previous_attestation_hash": "586a171afa714fe0d6f72fae5e2351407f2b49119e0f6221513ddd73efda6cf1"
    }
    
    with open("STARDARK_ATTESTATION.json", "w", encoding="utf-8") as f:
        json.dump(attestation_report, f, indent=2, sort_keys=True)
    print("[OK] Diario criptográfico evolutivo actualizado en STARDARK_ATTESTATION.json")
