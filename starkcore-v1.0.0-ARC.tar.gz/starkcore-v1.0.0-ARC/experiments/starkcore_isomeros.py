#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
StarkCore — Isomorfismo de Grafos Moleculares y Clases de Isómeros de Trayectoria
Autor: Luis Alberto Burciaga Miker
Ubicación: El Rosario / Ensenada, Baja California, México
Contexto: "Solo curiosiaba" — La abstracción molecular y el sesgo de trazabilidad.

Formulación Científica:
  StarkCore extiende el concepto clásico de identidad estructural incorporando una 
  dimensión de procedencia verificable. No contradice a la química; la amplía para 
  el dominio de los sistemas distribuidos con memoria criptográfica.
"""

import hashlib

class MoleculaTrayectoria:
    def __init__(self, formula_condensada, topologia_enlaces, historial_anclaje):
        self.formula = formula_condensada  
        self.grafo = topologia_enlaces     
        self.procedencia = historial_anclaje  

    def calcular_huella_identidad(self):
        hasher = hashlib.sha256()
        hasher.update(self.formula.encode('utf-8'))
        str_grafo = ",".join(f"{k}:{v}" for k, v in sorted(self.grafo.items()))
        hasher.update(str_grafo.encode('utf-8'))
        for paso in sorted(self.procedencia):
            hasher.update(paso.encode('utf-8'))
        return hasher.hexdigest()

def evaluar_isomorfismo_stark(m1, m2):
    print("\n====================================================================")
    print("=== ANÁLISIS DE ISOMORFISMO TOPOLÓGICO: QUÍMICA VS. STARKCORE ===")
    print("====================================================================")

    mismo_estado = m1.formula == m2.formula
    mismo_grafo = sorted(m1.grafo.items()) == sorted(m2.grafo.items())

    print(f"\n[Capa Sincrónica - Identidad Estructural (Qué es)]")
    print(f"  -> ¿Comparten Apariencia/Fórmula macroscópica? ({m1.formula}): {mismo_estado}")
    print(f"  -> ¿Comparten Grafo de Conectividad Estructural?: {mismo_grafo}")

    if mismo_estado and mismo_grafo:
        print("  => CLASIFICACIÓN QUÍMICA: Son la misma especie molecular exacta (Idéntica conectividad).")

    misma_procedencia = sorted(m1.procedencia) == sorted(m2.procedencia)

    print(f"\n[Capa Diacrónica - Identidad Histórica (De dónde viene)]")
    print(f"  -> ¿Comparten Línea Temporal de Procedencia (P)?: {misma_procedencia}")

    id_m1 = m1.calcular_huella_identidad()
    id_m2 = m2.calcular_huella_identidad()

    print(f"\n[Firma Criptográfica Final I_C]")
    print(f"  -> I_C(Molécula Síntesis Alfa): {id_m1[:24]}...")
    print(f"  -> I_C(Molécula Síntesis Beta): {id_m2[:24]}...")

    if mismo_estado and mismo_grafo and not misma_procedencia:
        print("\n💥 DIVERGENCIA CONTEXTUAL VALIDADA:")
        print("   Para la química, son indistinguibles estructuralmente.")
        print("   Para StarkCore, la identidad se ha bifurcado (d_Stark > 0).")
        print("   Aceptación: StarkCore extiende la identidad estructural agregando procedencia.")
        assert id_m1 != id_m2

if __name__ == "__main__":
    grafo_nucleo_estable = {
        "anillo_indol": "admitido",
        "cadena_lateral": "etilamina",
        "metilacion": "N,N-dimetil"
    }

    molecula_alfa = MoleculaTrayectoria(
        formula_condensada="C12H16N2",
        topologia_enlaces=grafo_nucleo_estable,
        historial_anclaje=["0a5df7415f92d330c77a90552bc61cf29faa96b3", "d43c574"]
    )

    molecula_beta = MoleculaTrayectoria(
        formula_condensada="C12H16N2",
        topologia_enlaces=grafo_nucleo_estable,
        historial_anclaje=["origen_desconocido_red_libre", "hash_externo_t7"]
    )

    evaluar_isomorfismo_stark(molecula_alfa, molecula_beta)
