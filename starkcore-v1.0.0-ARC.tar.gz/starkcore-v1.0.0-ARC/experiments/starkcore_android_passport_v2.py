#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
STARDARK Passport Protocol v2
Identidad con metabolismo para agentes autónomos y sistemas ciberfísicos.

Niveles oficiales de identidad (ampliados):
  G₀  = Ancla de nacimiento (génesis inyectado en fábrica, irreemplazable)
  I_C = Identidad Estructural  → hardware + firmware + pesos IA (JSON canónico)
  M(P)= Memoria / Linaje       → cadena de bloques de transformaciones (Merkle)
  ℰ   = Entorno / Attestation  → estado de hardware en el instante
  I_E = Identidad de Ejecución → H(I_C ‖ M(P) ‖ ℰ)
  Π   = Política de Evolución  → CONSTITUCIÓN: qué mutaciones están permitidas
  C_T = Certificado de Transición → prueba firmada por CA de que Δ ∈ Π
  I_A = Identidad Androide     → H(I_E ‖ Π ‖ C_T)   ← NUEVA CAPA

Máquina de estados del auditor:
  OBSERVED → VERIFIED → AUTHORIZED → EXECUTABLE
                ↓            ↓
          INCONSISTENT → QUARANTINE → REJECTED
"""

import hashlib, json, time

# ---------------------------------------------------------------------------
# AXIOMA XV — lo grabamos dentro del propio código
# ---------------------------------------------------------------------------
AXIOMA_XV = """
Axioma XV · Conservación de Linaje bajo Evolución Autónoma

  Un agente autónomo puede evolucionar, mutar, recalibrarse y repararse,
  siempre y cuando cada transformación pueda ser reconstruida
  y se demuestre que ocurrió dentro del espacio de políticas Π
  autorizadas para su clase de existencia.

  No es válido congelar al androide para conservar su identidad.
  Es válido exigir que cada nueva hoja crezca atada al árbol anterior.
"""

# ---------------------------------------------------------------------------
# Utilidades criptográficas canónicas
# ---------------------------------------------------------------------------
def H(x: str) -> str:
    return hashlib.sha256(x.encode("utf-8")).hexdigest()

def canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))

# ---------------------------------------------------------------------------
# 1. ANCLA DE NACIMIENTO G₀ — no se negocia, no se regenera
#    Bloquea el ataque del "clon con historia entera inventada"
# ---------------------------------------------------------------------------
class AnclaGenesis:
    def __init__(self, fabricante: str, serie: str, hw: dict, fw: str):
        self.payload = {
            "fabricante": fabricante,
            "serie":      serie,
            "hw_root":    hw,
            "fw_gnesis":  fw,
            "ts_utc":     time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        self.G0 = H(canon(self.payload))   # ← esto es la huella de nacimiento

    def __repr__(self):
        return f"G₀ = {self.G0[:16]}…"

# ---------------------------------------------------------------------------
# 2. ENTRADA DE LINAJE — cada hecho histórico lleva su propio hash + padre
#    Memoria ≠ Testimonio: no basta escribir el pasado, debe estar encadenado
# ---------------------------------------------------------------------------
class PasoLinaje:
    def __init__(self, tipo: str, descripcion: str, padre_hash: str, meta: dict = None):
        self.tipo = tipo
        self.descripcion = descripcion
        self.meta = meta or {}
        self.padre = padre_hash
        self.hash = H(canon([self.tipo, self.descripcion, self.meta, self.padre]))

# ---------------------------------------------------------------------------
# 3. POLÍTICA Π — CONSTITUCIÓN del agente: QUÉ se puede cambiar
# ---------------------------------------------------------------------------
class PoliticaEvolucion:
    """Declara qué transformaciones están autorizadas para esta clase."""
    def __init__(self, clase_agente: str, reglas: list):
        self.clase = clase_agente
        self.reglas = reglas          # lista de {"tipo":"…","permite":bool}
        self.id = H(canon([clase_agente, reglas]))

    def permite(self, paso: PasoLinaje) -> bool:
        for r in self.reglas:
            if r["tipo"] == paso.tipo:
                return bool(r["permite"])
        return False   # regla de cierre: lo no expresamente permitido = prohibido

# ---------------------------------------------------------------------------
# 4. CERTIFICADO DE TRANSICIÓN C_T — prueba de que Δ ∈ Π y fue autorizado
# ---------------------------------------------------------------------------
class CertificadoTransicion:
    def __init__(self, politica: PoliticaEvolucion, paso: PasoLinaje, autoridad: str):
        self.politica_id = politica.id
        self.paso_hash   = paso.hash
        self.autoridad   = autoridad
        self.valido      = politica.permite(paso)   # C_T solo existe si Δ ∈ Π
        self.hash        = H(canon([self.politica_id, self.paso_hash, self.autoridad, self.valido]))

# ---------------------------------------------------------------------------
# 5. EL PASAPORTE ANDROIDE — calcula I_C → M(P) → I_E → I_A
# ---------------------------------------------------------------------------
class PasaporteAndroide:
    def __init__(self,
                 genesis: AnclaGenesis,
                 estructura: dict,
                 entorno: str,
                 politica: PoliticaEvolucion):
        self.genesis   = genesis
        self.estructura= estructura    # I_C: qué es
        self.entorno   = entorno       # ℰ: attestation HW
        self.politica  = politica      # Π: constitución
        self.linaje    = [PasoLinaje("G0", "nacimiento en fábrica", genesis.G0)]

    # --- identidades canónicas --------------------------------------------
    @property
    def I_C(self) -> str: return H(canon(self.estructura))

    @property
    def M_P(self) -> str:
        """Raíz Merkle del diario criptográfico de vida del androide."""
        hojas = [p.hash for p in self.linaje]
        while len(hojas) > 1:
            if len(hojas) % 2: hojas.append(hojas[-1])
            hojas = [H(hojas[i]+hojas[i+1]) for i in range(0,len(hojas),2)]
        return hojas[0]

    @property
    def I_E(self) -> str:
        """Identidad de Ejecución = estructura + linaje + entorno."""
        return H(self.I_C + self.M_P + H(self.entorno))

    def I_A(self, C_T: CertificadoTransicion | None = None) -> str:
        """Identidad Androide completa: I_E + constitución + transición."""
        ct = C_T.hash if C_T else H("NINGUNA_TRANSICION")
        return H(self.I_E + self.politica.id + ct)

    # --- acciones del agente ----------------------------------------------
    def aplicar_transformacion(self,
                               tipo: str,
                               descripcion: str,
                               nueva_estructura: dict,
                               autoridad: str = "STARK_CA") -> CertificadoTransicion | None:
        """Intenta mutar. Devuelve C_T solo si la política lo permite."""
        paso = PasoLinaje(tipo, descripcion, self.linaje[-1].hash)
        ct   = CertificadoTransicion(self.politica, paso, autoridad)
        if not ct.valido:
            return None                 # ← Π dijo NO: metabolismo bloqueado
        self.estructura = nueva_estructura
        self.linaje.append(paso)
        return ct

# ---------------------------------------------------------------------------
# 6. AUDITOR STARK — máquina de estados FORMAL, no "me parece raro"
# ---------------------------------------------------------------------------
ESTADOS = ["OBSERVED","VERIFIED","AUTHORIZED","EXECUTABLE",
           "INCONSISTENT","QUARANTINE","REJECTED"]

class AuditorStark:
    def __init__(self, referencia: PasaporteAndroide):
        self.ref = referencia

    def auditar(self,
                sujeto: PasaporteAndroide,
                C_T: CertificadoTransicion | None = None) -> tuple[str, str]:
        """Devuelve (estado_final, motivo)."""
        estado = "OBSERVED"

        # PASO 1 — Ancla de nacimiento coincide?
        if sujeto.genesis.G0 != self.ref.genesis.G0:
            return ("REJECTED",
                    f"Ancla G₀ rota. Clon o historia inventada.\n"
                    f"  esperado {self.ref.genesis.G0[:12]}…\n"
                    f"  recibido {sujeto.genesis.G0[:12]}…")

        # PASO 2 — Cadena del linaje íntegra? (M(P) bien encadenada)
        for i in range(1, len(sujeto.linaje)):
            if sujeto.linaje[i].padre != sujeto.linaje[i-1].hash:
                return ("QUARANTINE",
                        f"Ruptura de cadena en paso {i}: memoria ≠ testimonio")
        estado = "VERIFIED"

        # PASO 3 — ¿Es exactamente el mismo que en fábrica?
        if sujeto.I_C == self.ref.I_C and sujeto.M_P == self.ref.M_P:
            return ("EXECUTABLE",
                    "Identidad idéntica a referencia. Cero desviaciones.")

        # PASO 4 — ¿Cambió? Entonces EXIGIMOS C_T válido atado a Π
        if C_T is None or not C_T.valido:
            return ("QUARANTINE",
                    "Mutación detectada SIN Certificado de Transición C_T.\n"
                    "  El cambio puede ser legítimo, pero no hay prueba de que Π lo autorizara.")
        if C_T.paso_hash != sujeto.linaje[-1].hash:
            return ("REJECTED",
                    "Certificado C_T no corresponde al último paso del linaje.")
        if C_T.politica_id != self.ref.politica.id:
            return ("REJECTED",
                    "Certificado emitido bajo una constitución Π distinta.")

        estado = "AUTHORIZED"
        return ("EXECUTABLE",
                f"Mutación autorizada por C_T={C_T.hash[:12]}…\n"
                f"  El agente EVOLUCIONÓ dentro de su constitución. I_A={sujeto.I_A(C_T)[:16]}…")

# ---------------------------------------------------------------------------
# 7. BANCO DE PRUEBAS — 4 ESCENARIOS REALES
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    separador = "─" * 72
    print(separador)
    print("  STARDARK Passport Protocol v2  ·  Axioma XV")
    print(separador)
    print(AXIOMA_XV)

    # --- REFERENCIA: androide médico tal cual salió de fábrica ------------
    hw = {"cpu":"stark_quantum_v2","brazo":"kuka_lbr_iiwa","seguridad":"silicon_root"}
    fw = {"modelo_ia":"surgeon_neural_net_v4.2","firmware":"efector_final_patch_09"}
    estructura_fabrica = {**hw, **fw}

    G0 = AnclaGenesis("StarkCore MedTech", "SRG-MED-00042", hw, fw["firmware"])

    Π_medica = PoliticaEvolucion("ROBOT_QUIRURGICO_CLASE_III", [
        {"tipo":"G0",                                  "permite": True},
        {"tipo":"CALIBRACION_OPTICA",                  "permite": True},
        {"tipo":"CALIBRACION_MECANICA_EFECTOR",        "permite": True},
        {"tipo":"FIRMWARE_PATCH_SEGURIDAD",            "permite": True},
        {"tipo":"ACTUALIZACION_IA_MENOR",              "permite": True},
        {"tipo":"REEMPLAZO_CPU",                       "permite": False},  # ← PROHIBIDO
        {"tipo":"CAMBIO_MODELO_IA_MAYOR",              "permite": False},  # ← PROHIBIDO
    ])

    ALFA = PasaporteAndroide(G0, dict(estructura_fabrica),
                             "attestation_hw_arm64_secure_boot_OK", Π_medica)
    auditor = AuditorStark(ALFA)

    # === ESCENARIO 1 — Alfa: idéntico a fábrica ==========================
    print("\n" + separador)
    print("🎯 ESCENARIO 1 · Alfa — sin modificaciones")
    print(separador)
    st, mot = auditor.auditar(ALFA)
    print(f"ESTADO FINAL: {st}\n{mot}")

    # === ESCENARIO 2 — Beta: CALIBRACIÓN LEGÍTIMA (dentro de Π) ==========
    BETA = PasaporteAndroide(G0, dict(estructura_fabrica),
                             "attestation_hw_arm64_secure_boot_OK", Π_medica)
    nueva_est = dict(BETA.estructura)
    nueva_est["firmware"] = "efector_final_patch_09_calib_2026_07"
    CT_beta = BETA.aplicar_transformacion(
        "CALIBRACION_OPTICA",
        "Ajuste lente estéreo post-reparación pinza #3",
        nueva_est,
        autoridad="STARK_CA_MEDICA")

    print("\n" + separador)
    print("🟡 ESCENARIO 2 · Beta — calibrado en clínica (MUTACIÓN LEGÍTIMA)")
    print(separador)
    st, mot = auditor.auditar(BETA, CT_beta)
    print(f"ESTADO FINAL: {st}\n{mot}")
    print("  ✅ Antes este caso habría sido RECHAZADO. Ahora se acepta porque")
    print("     demostró que el cambio estaba en Π y trae C_T firmado.")

    # === ESCENARIO 3 — Gamma: cambió firmware SIN C_T ====================
    GAMMA = PasaporteAndroide(G0, dict(estructura_fabrica),
                              "attestation_hw_arm64_secure_boot_OK", Π_medica)
    GAMMA.estructura["firmware"] = "firmware_mercado_negro_pwned_v666"
    # ⚠️  salta la API .aplicar_transformacion() → no hay C_T

    print("\n" + separador)
    print("🟠 ESCENARIO 3 · Gamma — firmware alterado SIN certificado")
    print(separador)
    st, mot = auditor.auditar(GAMMA)
    print(f"ESTADO FINAL: {st}\n{mot}")

    # === ESCENARIO 4 — Delta: CLON con G₀ falso e historia inventada =====
    G0_falso = AnclaGenesis("MercadoNegro S.A.", "CLON-999", hw, fw["firmware"])
    DELTA = PasaporteAndroide(G0_falso, dict(estructura_fabrica),
                              "attestation_hw_arm64_secure_boot_OK", Π_medica)

    print("\n" + separador)
    print("🔴 ESCENARIO 4 · Delta — clon con ancla de nacimiento falsa")
    print(separador)
    st, mot = auditor.auditar(DELTA)
    print(f"ESTADO FINAL: {st}\n{mot}")

    # === RESUMEN =========================================================
    print("\n" + separador)
    print("📊 RESUMEN · STARDARK Passport Protocol v2")
    print(separador)
    print("  G₀  → bloquea clones con historia inventada")
    print("  Π   → constitución: define qué puede mutar")
    print("  C_T → prueba firmada de que el cambio pasó por Π")
    print("  I_A → identidad ANDROIDE completa, con metabolismo")
    print("  Ω   → máquina de estados: no hay 'me parece raro'")
    print(separador)
    print("Axioma XV validado en 4/4 escenarios.")
