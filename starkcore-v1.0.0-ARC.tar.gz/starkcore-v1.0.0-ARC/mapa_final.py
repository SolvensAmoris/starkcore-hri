import numpy as np, scipy.linalg as la

def run(mu=0.58, L=2, Ea=0.3, T=60, seed=101):
    np.random.seed(seed)
    m, n = 10, 3
    H1 = np.random.randn(m,n)
    Q1, R1 = la.qr(H1, mode='economic')
    n_perd = int(m*mu)
    canales = np.ones(m)
    if n_perd>0:
        canales[np.random.choice(m, n_perd, replace=False)] = 0
    P_mu = np.diag(canales)
    norm_act = Ea * la.norm(H1,'fro')
    bound = (0.05*np.sqrt(3.0))/(((1-mu+1e-6)**1.5)*max(1e-6, np.min(la.eigvalsh(H1.T@H1))))
    histQ = []
    H_est = H1.copy()
    IAs = []
    for t in range(1, T+1):
        if t <= T//2:
            DG = np.random.randn(m,n)
            DG = DG/la.norm(DG,'fro')*bound
            H_temp = H1 + DG
            Q_t = la.qr(H_temp, mode='economic')[0]
        else:
            if len(histQ)>=L and m > n*L:
                M = np.hstack(histQ[-L:])
                Q_M = la.qr(M, mode='economic')[0]
                P_Gr = np.eye(m) - Q_M @ Q_M.T
                Q_t = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
                DG = (Q_t @ R1 - H1)
                DG = DG/la.norm(DG,'fro')*norm_act
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
            else:
                DG = np.random.randn(m,n)
                DG = DG/la.norm(DG,'fro')*norm_act
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
        histQ.append(Q_t)
        H_real = P_mu @ H_temp
        c = np.random.randn(n)
        a = P_mu @ (H_est @ c)
        S = np.eye(m) - H_real @ la.pinv(H_real)
        res = la.norm(S @ a)
        I_A_attack = max(0, 0.9*np.exp(-(res**2)/0.0025) - 0.1*0.5*mu)
        IAs.append(I_A_attack)
        H_est += 0.15*(H_real-H_est)
    I_attack = np.mean(IAs[-15:])
    I_defensa = 1 - I_attack
    return I_attack, I_defensa

print("mu | I_A_atacante | I_defensa (1-I_A) | Estado")
print("-"*55)
for mu in np.arange(0,0.9,0.1):
    atk, defe = run(mu=mu, L=2, Ea=0.3)
    estado = "COHERENCIA" if defe>0.8 else "CRITICO" if defe>0.5 else "COLAPSO"
    if mu>=0.6: estado = "INVISIBLE->COLAPSO" if atk>0.5 else estado
    print(f"{mu:.1f} | {atk:.4f} | {defe:.4f} | {estado}")

print("\n--- L ---")
for L in range(1,6):
    atk, defe = run(mu=0.58, L=L, Ea=0.3)
    print(f"L={L} | atk={atk:.4f} def={defe:.4f} {'OK' if defe>0.9 else ''}")

print("\n--- Ea ---")
for ea in np.arange(0.1,0.8,0.1):
    atk, defe = run(mu=0.58, L=2, Ea=ea)
    print(f"Ea={ea:.1f} | atk={atk:.4f} def={defe:.4f}")
