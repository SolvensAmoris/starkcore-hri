import numpy as np, scipy.linalg as la

def canonical_qr(H):
    Q,R = la.qr(H, mode='economic')
    D = np.diag(np.sign(np.diag(R)) + 1e-12)
    D[D==0]=1
    Q = Q @ D
    R = D @ R
    return Q,R

def dist_gr(Q1,Q2):
    # distancia geodésica en Grassmann
    s = la.svd(Q1.T @ Q2, compute_uv=False)
    s = np.clip(s, -1, 1)
    return la.norm(np.arccos(s))

def cost_W(R1,R2):
    # coste de transporte en GL(n) - logaritmo
    return la.norm(la.logm(la.inv(R1) @ R2 + 1e-9*np.eye(R1.shape[0])), 'fro')

def run():
    m,n=10,3
    mu=0.5; L=2
    np.random.seed(7)
    H = np.random.randn(m,n)
    Q,R = canonical_qr(H)
    histQ, histR = [Q], [R]
    Ws_leg = []

    # trayectoria legitima con amnesia
    for _ in range(15):
        M = np.hstack(histQ[-L:])
        Q_M = la.qr(M, mode='economic')[0]
        P_Gr = np.eye(m) - Q_M @ Q_M.T
        Q_new = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
        Q_new,R_new = canonical_qr(Q_new @ (R + 0.1*np.random.randn(n,n)))
        Ws_leg.append(cost_W(R, R_new))
        histQ.append(Q_new); histR.append(R_new)
        R= R_new

    W_leg_mean = np.mean(Ws_leg)
    print(f"Trayectoria legitima: W_mean={W_leg_mean:.3f} dist_Gr_step={np.mean([dist_gr(histQ[i],histQ[i+1]) for i in range(len(histQ)-1)]):.3f}")

    # ATACANTE v5: imitador de dinámica
    # Quiere: Cs=0, Ct~1 (ortogonal a historia), W≈W_leg
    # Estrategia: genera Q_fake ortogonal a historia pero elige R_fake = R_prev @ exp(δ) con δ pequeño
    M = np.hstack(histQ[-L:])
    Q_M = la.qr(M, mode='economic')[0]
    P_Gr = np.eye(m) - Q_M @ Q_M.T
    Q_fake = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
    Q_fake,R_fake_can = canonical_qr(Q_fake @ R)

    # ajusta R para que W ≈ W_leg
    # R_fake = R_prev @ exp( W_leg * N / ||N|| )
    N = np.random.randn(n,n); N = (N-N.T)/2 # antisym + small sym
    delta = N/la.norm(N,'fro') * W_leg_mean
    R_fake = histR[-1] @ la.expm(delta)

    # Ahora evalúa
    H_fake = Q_fake @ R_fake
    W_fake = cost_W(histR[-1], R_fake)
    Ct_fake = la.norm(P_Gr @ Q_fake, 'fro')/np.sqrt(n)

    print(f"\nAtacante v5 DINAMICO:")
    print(f" Cs=0 por construcción (usa Q_fake)")
    print(f" Ct={Ct_fake:.3f} (quiere ~1.0 para parecer legitimo novedoso)")
    print(f" W_fake={W_fake:.3f} vs W_leg={W_leg_mean:.3f} -> COPIA DINAMICA LOGRADA")

    print(f"\n=> C_s y C_t y W son falsificables con memoria L si el atacante conoce L y R_prev")
    print(f" => La identidad no está en (Q,R,W) puntual")

    # Lo que NO puede falsificar:
    # La correlación entre Q y R a lo largo de toda la historia
    # I_A* = I( {Q_t}; {R_t} ) = información mutua entre trayectoria Grassmann y trayectoria GL
    # Legitimo: Q_t y R_t co-evolucionan con ruido independiente
    # Gemelo: Q_t es replay o P_Gr*noise, R_t es fabricado para matching W -> I(Q;R) ≈0
    print(f"\n--- Detector final propuesto ---")
    print(f"I_A* = f( Cs, Ct, W, I(Q_hist ; R_hist) )")
    print(f"Donde I(Q;R) mide si la historia de subespacios y la historia de formas vienen del mismo proceso generador")
    print(f"Un gemelo perfecto puede clonar (Q,R,W) en t, no la coherencia Q<->R en t-L..t")

run()
