# Security Policy

## Supported Versions

| Version | Supported |
|----------|-----------|
| main | ✅ |
| pre-0.1 | ❌ |

---

## Reporting a Vulnerability

Please report vulnerabilities privately rather than through public issues.

Contact:

<security@example.com>

Include:

- Description
- Expected behavior
- Observed behavior
- Impact assessment
- Reproduction steps
- Relevant logs

An acknowledgement will normally be provided within 48 hours.

When appropriate, fixes may include updated cryptographic attestations and documentation.
