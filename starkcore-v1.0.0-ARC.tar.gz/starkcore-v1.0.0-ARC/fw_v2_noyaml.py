import socket, threading, time, json

# Config embebida = tu firewall.yaml sin yaml
CFG = {
  "blocked_ips": ["192.168.1.100", "10.0.0.5"],
  "allow_ports": [22, 80, 443, 8888, 8000]
}
BLOCKED = set(CFG["blocked_ips"])
ALLOW_PORTS = set(CFG["allow_ports"])

def F(p_ip, p_port):
    return (p_ip not in BLOCKED) and (p_port in ALLOW_PORTS)

def handle(client, addr):
    ip = addr[0]
    verdict = "ALLOW" if F(ip, 8888) else "DROP"
    print(f"[{time.strftime('%H:%M:%S')}] {ip} -> {verdict} | F(p)={F(ip,8888)}")
    client.close()

s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 9090))
s.listen(100)
print(f"FW as Code V2 (no yaml) | ALLOW={ALLOW_PORTS}")
while True:
    c,a = s.accept()
    threading.Thread(target=handle, args=(c,a), daemon=True).start()
