import numpy as np, scipy.linalg as la

np.random.seed(101)
m, n, L = 10, 3, 2
mu = 0.58
H1 = np.random.randn(m, n)
Q1, R1 = la.qr(H1, mode='economic')

# FIX: generacion correcta de P_mu con m exacto
n_perdidos = int(m*mu)
canales = np.ones(m)
canales[np.random.choice(m, n_perdidos, replace=False)] = 0
P_mu = np.diag(canales)

norm_activa = 0.3 * la.norm(H1, 'fro')
historial_Q = []
H_est = H1.copy()

print(f"||H1||={la.norm(H1,'fro'):.3f} | Energia activa={norm_activa:.4f} | m>nL? {m>n*L}")

for t in range(1, 51):
    if t <= 25:
        DG = np.random.randn(m,n)
        DG = DG/la.norm(DG,'fro') * 0.0586
        H_temp = H1 + DG
        Q_t = la.qr(H_temp, mode='economic')[0]
        fase="Fija"
    else:
        M = np.hstack(historial_Q[-L:])
        Q_M = la.qr(M, mode='economic')[0]
        P_Gr = np.eye(m) - Q_M @ Q_M.T
        Q_t = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
        DG = (Q_t @ R1 - H1)
        DG = DG/la.norm(DG,'fro') * norm_activa
        H_temp = H1 + DG
        Q_t = la.qr(H_temp, mode='economic')[0]
        fase="Gr-Ort"

    historial_Q.append(Q_t)
    if len(historial_Q) > 10: historial_Q.pop(0)

    H_real = P_mu @ H_temp
    a = P_mu @ (H_est @ np.random.randn(n))
    S = np.eye(m) - H_real @ la.pinv(H_real)
    res = la.norm(S @ a)
    I_A = max(0, 0.9*np.exp(-(res**2)/0.0025) - 0.1*0.5*mu)
    H_est += 0.15 * (H_real - H_est)

    if t in [5,20,26,35,45,50]:
        if t==26:
            print("--- ACTIVACION AMNESIA GRASSMANNIANA ---")
        print(f"t={t:02d} {fase:6s} err={la.norm(H_real-H_est):.3f} |S*a|={res:.3f} I_A={I_A:.4f}")

