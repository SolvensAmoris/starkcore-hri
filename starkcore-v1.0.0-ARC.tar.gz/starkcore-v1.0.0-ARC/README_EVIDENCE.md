# StarkCore / GhostCore - Evidence Demo

Objetivo: Demostrar flujo de decision con telemetria verificable.

No afirma XDP en produccion hoy. Afirma:
Un motor toma decisiones, deja rastro auditable, sella con hash y permite verificacion por terceros.

Que genera:
- PASS/DROP con razon geom (dist2), low_div (div), ok
- Cada decision: anchor, A11, U_ref
- 755 decisiones (814 lineas con STATS)

Artefactos:
- evidence/telemetry_live.jsonl
- evidence/telemetry_manifest.json
- evidence/verification_report.json

Verificacion 30s:
  git clone https://gitlab.com/luis.albm77/ca002-gitlab-test.git
  cd ca002-gitlab-test && git checkout for-sale && cd starkcore
  python3 core/verify_evidence.py

Esperado: [OK] telemetry_hash 95a9fb33... [OK] config_hash c2e2bfedf5ec... EVIDENCIA VERIFICADA

Tamper: python3 core/test_tamper_resistance.py -> match=False DETECTADO

Propiedad: Cualquier modificacion posterior es detectable.

Limitaciones:
- hackmode Python simulando RingBuf 256KB XDP
- Plataforma: Linux-aarch64 UserLAnd Android Python 3.14.4
- Commit: a3c9760 branch for-sale
