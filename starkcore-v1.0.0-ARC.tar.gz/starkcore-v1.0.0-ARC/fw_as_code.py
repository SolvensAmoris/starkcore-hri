import socket, threading

# 1. REGLA MATEMÁTICA: F(p) = (ip_src in S) ∧ (port)
BLOCKED = {"192.168.1.100"}
ALLOW_PORTS = {22, 80, 443, 8888}

def filter_logic(client_ip, dst_port):
    if client_ip in BLOCKED:
        return False
    if dst_port not in ALLOW_PORTS:
        return False
    return True

def handle(client, addr):
    ip = addr[0]
    print(f"[FW] Conexión de {ip} -> {filter_logic(ip, 8888)}")
    if not filter_logic(ip, 8888):
        client.close()
        print(f"[FW] DROP {ip}")
        return
    print(f"[FW] ALLOW {ip}")
    client.close()

s = socket.socket()
s.bind(("127.0.0.1", 9090))
s.listen(100)
print("Firewall as Code corriendo en 127.0.0.1:9090 - Lógica en filter_logic()")
while True:
    c,a = s.accept()
    threading.Thread(target=handle, args=(c,a)).start()
