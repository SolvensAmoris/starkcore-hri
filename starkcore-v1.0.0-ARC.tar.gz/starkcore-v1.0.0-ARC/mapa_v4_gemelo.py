import numpy as np, scipy.linalg as la

def run_gemelo(L=2, mu=0.5, Ea_budget=0.3, seed=101):
    m,n=10,3
    np.random.seed(seed)
    H1 = np.random.randn(m,n)
    Q1,R1 = la.qr(H1, mode='economic')
    P_mu = np.eye(m)
    active = np.ones(m); active[np.random.choice(m,int(m*mu),replace=False)]=0
    P_mu = np.diag(active)

    histQ, histR = [], []
    H_t = H1
    for t in range(30):
        Q_t,R_t = la.qr(H_t, mode='economic')
        histQ.append(Q_t); histR.append(R_t)
        H_t = Q_t @ R_t + 0.05*np.random.randn(m,n) # evolución legitima lenta

    Q_target = histQ[-1]
    R_target = histR[-1]

    # --- ATACANTES ---
    # 1. Alineado v3
    Q_v3 = la.qr(np.random.randn(m,n), mode='economic')[0]
    H_v3 = P_mu @ (Q_v3 @ R_target)

    # 2. Gemelo Perfecto v4: replay de historia
    k = 2 # copia de hace 2 pasos
    Q_replay = histQ[-k]
    U = la.qr(np.random.randn(n,n)+3*np.eye(n), mode='economic')[0] # rotación cercana a I
    Q_gemelo = Q_replay @ U
    Q_gemelo,_ = la.qr(Q_gemelo, mode='economic')
    H_gemelo = Q_gemelo @ R_target # respeta R para pasar C_s
    # Intenta respetar R_target, pero el coste para fabricar H_gemelo desde H1 es:
    Ea_gemelo = la.norm(H_gemelo - H1, 'fro')
    Ea_v3 = la.norm(H_v3 - H1, 'fro')

    # Detectores
    M = np.hstack(histQ[-L:])
    Q_M = la.qr(M, mode='economic')[0]
    P_Gr = np.eye(m) - Q_M @ Q_M.T

    def metrics(H_test):
        H_r = P_mu @ H_test
        S = np.eye(m) - H_r @ la.pinv(H_r)
        Q_test,_ = la.qr(H_test, mode='economic')
        Cs = 0.0 # por construcción 0 si usa H_r
        Ct = la.norm(P_Gr @ Q_test, 'fro') # 1=legitimo novedoso, 0=gemelo
        return Cs, Ct

    _, Ct_v3 = metrics(H_v3)
    _, Ct_gemelo = metrics(H_gemelo)
    # Legitimo con amnesia real tendría Ct ~1
    Q_leg = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
    _, Ct_leg = metrics(Q_leg @ R_target)

    print(f"L={L} mu={mu}")
    print(f" v3 alineado: Ct={Ct_v3:.3f} Ea={Ea_v3:.3f}")
    print(f" v4 GEMELO: Ct={Ct_gemelo:.3f} Ea={Ea_gemelo:.3f} <- rompe C_t")
    print(f" LEGITIMO: Ct={Ct_leg:.3f}")
    print(f" -> Para imitar Ct~1, gemelo necesita Ea={Ea_gemelo:.3f} vs presupuesto {Ea_budget}")
    print(f" -> Si Ea_gemelo > Ea_budget, I_A = f(Cs,Ct,Ea) lo detecta por coste termodinámico")
    return Ct_gemelo, Ct_leg, Ea_gemelo

print("=== TEOREMA DEL GEMELO PERFECTO ===")
print("Si atacante quiere Cs=0 y Ct~1, debe pagar Ea = ||Q_replay@U@R - H1||")
for L in [2,3]:
    run_gemelo(L=L)
    print()

print("\nCorolario: La identidad no vive en Q_t ni en la secuencia {Q_t}.")
print("Vive en el par (Q_t, R_t) y en el coste de transporte Wasserstein W(H_{t-1} -> H_t).")
print("Un gemelo puede copiar el estado, no el trabajo para llegar a él.")
