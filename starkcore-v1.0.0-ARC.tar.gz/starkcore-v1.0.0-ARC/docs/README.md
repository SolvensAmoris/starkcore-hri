# Starkcore V24 - Merkle Finality + Bitcoin Timestamp

**Compresión logarítmica de logs con prueba Merkle + sello inmutable en Bitcoin vía OpenTimestamps.**

## Características principales
- Generación eficiente de Merkle Root
- Pruebas de inclusión (Merkle Proof)
- Timestamp inmutable con OpenTimestamps (Bitcoin)
- Verificación determinista y ligera
- Dockerfile listo para producción
- Código verificable por SHA256

## Verificación rápida

```bash
# Ejecutar demo
python core/v24_merkle.py

# Verificar timestamp Bitcoin
ots verify starkcore-proof.json.ot
