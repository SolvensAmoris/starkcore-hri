# Experimentos falsables CA-005

for i in 1..10000:
  U = random_universe()
  A = random_amendment()
  result = verify(U,A)

Registro: [U, A, expected, got]

Preguntas a romper:
1. ¿Corrupcion aceptada? A invalida -> PASS = BUG CRITICO
2. ¿Evolucion valida rechazada? A valida -> BLOCKED = BUG
3. ¿Kernel mutable sin deteccion?
4. ¿evolvable fuera de policy aceptado?

Metrica: 0 falsos positivos, 0 falsos negativos.
