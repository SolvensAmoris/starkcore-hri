# StarkCore - Proof of Existence

**Merkle Root:** `3b1a7de5d466b5cd96ed08ade1b52b0f8cf9214df0cd8247c696cd78f6eb39af`
**Block Hash (regtest):** `00007ad4cb74402481c7b90e6a86f70d1d508672bc6102f4fa0570116702111b`
**Nonce:** 39317
**OTS Proof:** `starkcore-proof.json.ots`

Este código fue anclado en Bitcoin mainnet via OpenTimestamps el 28-07-2026.
Para verificar: `ots verify starkcore-proof.json.ots -f starkcore-proof.json`

Tras 1-2 horas, correr `ots upgrade starkcore-proof.json.ots` mostrará el bloque BTC real.
