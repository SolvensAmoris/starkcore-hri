# StarkCore Proof Boundary - V∞+Ω+1

## Trust Root (parte del protocolo, no texto externo)
No se elimina el axioma. Se hace visible y auditable.

trust_root = {type: external_anchor, id: hash(witnesses+evidence+date)}
kernel_identity = hash(kernel_bytes + RFC8785 + interpreter_hash + trust_root.id)
State.id = hash(parent + data + finality_log + kernel_identity)

## Demuestra (interno)
- identidad, continuidad, transicion constitucional, autorizacion temporal, finality, contradicciones observables, reproducibilidad

## No demuestra (requiere ancla externa)
- verdad metafisica, primacia genesis sin reloj, no-equivocacion universal, real vs ficcion perfecta O(R)=O(F)

Sistema cerrado -> consistencia
Sistema abierto + trust_root -> realidad
