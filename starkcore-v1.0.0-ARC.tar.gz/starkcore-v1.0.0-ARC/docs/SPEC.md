# StarkCore v20-freeze - SPEC

## Pregunta
No: "¿Sigue siendo idéntico?"
Si: "¿Puede demostrar que cada cambio siguió su constitución anterior?"

## Identidad
ID = SHA256(estado_canonico)
estado = {height, authorities, data, rules, kernel, proposals}

## Continuidad
U{n+1} válido si:
1. from = ID(U{n})
2. to = ID(U{n+1})
3. firma válida de autoridad en U{n}
4. height = n+1, valid_at_height = n
5. quorum y timelock según lo que cambia (evaluado con rules de U{n}, no de U{n+1})

## Meta-gobernanza tiered
rules = {
  data: {quorum:1, timelock:0} # cambiar dato
  authorities: {quorum:2, timelock:1} # cambiar quien manda, necesita propuesta + 1 altura
  rules: {quorum:3, timelock:2, emergency_q:2, emergency_t:10} # cambiar constitucion
}
changed = diff(parent, new)
need_q = max(rules[f].quorum for f in changed)
need_t = max(rules[f].timelock for f in changed)

## Timelock
proposals: {prop_hash: altura_propuesta}
Para cambiar con timelock, new debe incluir pending=prop_hash y parent.height - prop_height >= need_t

## Emergency
Si height - last_progress >= emergency_t, authorities pueden usar emergency_q para degradar quorum y no congelarse.

## Ataques que debe rechazar
1. Dictador rules: A baja quorum a 1 solo
2. Stale: firma de altura 0 reusada en altura 1
3. Sin propuesta: cambio de authorities sin propuesta previa
4. Compuesto: cambiar data+authorities+rules con quorum 1
5. Fork: dos hijos válidos del mismo parent (debe detectarse, no ambos aceptarse)

Si pasa estos 5 + sim 100 rondas con B muerto y M malicioso, es v20-freeze.
