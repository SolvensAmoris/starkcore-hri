import numpy as np, scipy.linalg as la

def detector_grassmann(Q_t, histQ, L):
    """Mide si Q_t viene de evolución continua o de salto alineado"""
    if len(histQ) < L:
        return 0.0
    M = np.hstack(histQ[-L:])
    Q_M = la.qr(M, mode='economic')[0]
    P_Gr = np.eye(Q_t.shape[0]) - Q_M @ Q_M.T
    # Norma de la componente ortogonal a la historia
    orto = la.norm(P_Gr @ Q_t, 'fro') / np.sqrt(Q_t.shape[1])
    # Legitimo con amnesia debe tener orto ~ 1 (viene de fuera)
    # Alineado que imita H_real tendrá orto ~ 0 (viene de dentro)
    return orto

def run_alineado(mu=0.5, L=2, seed=101):
    m,n=10,3
    np.random.seed(seed)
    H1 = np.random.randn(m,n)
    _, R1 = la.qr(H1, mode='economic')
    P_mu = np.eye(m)
    P_mu[np.random.choice(m, int(m*mu), replace=False), np.random.choice(m, int(m*mu), replace=False)] = 0
    # simplificamos P_mu diag para legibilidad
    P_mu = np.diag(np.diag(P_mu))
    if np.sum(np.diag(P_mu)) <= n:
        return None
    histQ = []
    res_S_alineado, orto_alineado = [], []
    res_S_leg, orto_leg = [], []

    H_t = H1
    for t in range(40):
        Q_t = la.qr(H_t, mode='economic')[0]
        histQ.append(Q_t)
        H_real = P_mu @ H_t
        S = np.eye(m) - H_real @ la.pinv(H_real)

        # 1. Atacante ALINEADO: elige c' para que a esté en Col(H_real)
        c_al = np.random.randn(n)
        a_alineado = H_real @ c_al # S*a = 0 por construccion
        res_S_alineado.append(la.norm(S @ a_alineado))
        orto_alineado.append(detector_grassmann(Q_t, histQ[:-1], L))

        # 2. Legitimo siguiente con amnesia
        if len(histQ) >= L and m > n*L:
            M = np.hstack(histQ[-L:])
            Q_M = la.qr(M, mode='economic')[0]
            P_Gr = np.eye(m) - Q_M @ Q_M.T
            Q_next = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
            H_t = Q_next @ R1
            H_real_next = P_mu @ H_t
            S_next = np.eye(m) - H_real_next @ la.pinv(H_real_next)
            c_leg = np.random.randn(n)
            a_leg = H_real_next @ c_leg
            res_S_leg.append(la.norm(S_next @ a_leg))
            orto_leg.append(detector_grassmann(Q_next, histQ, L))
        else:
            H_t = np.random.randn(m,n)

    print(f"mu={mu} L={L}")
    print(f" Ataque ingenuo: S*a >>0 detectable")
    print(f" Ataque ALINEADO: S*a = {np.mean(res_S_alineado):.2e} -> INVISIBLE para S")
    print(f" Pero orto_Gr alineado = {np.mean(orto_alineado):.3f} vs legitimo = {np.mean(orto_leg):.3f}")
    print(f" Conclusión: necesitas detector de 2do orden. I_A no puede ser solo ||S a||")
    return np.mean(orto_alineado), np.mean(orto_leg)

for L in [1,2,3]:
    run_alineado(mu=0.5, L=L)
