"""
StarkCore — V6 Bioacústico: Tursiops truncatus
Autor: Luis Alberto Burciaga Miker — StarkCore Lab — 2026-07-30
Teorema: Identidad = restricción + historia + coherencia del generador
Φ_L = (Q_{t-L:t}, R_{t-L:t}, C_{t-L:t})
"""
import numpy as np, scipy.linalg as la

def simular():
    np.random.seed(42)
    n, m, T, L = 3, 10, 50, 2
    assert m > n*L, f"L>{(m-1)//n} viola L*"
    mu = 0.58
    mu_star = 1 - n/m
    assert mu < mu_star
    sigma, tau = 0.05, 3.0

    H1 = np.random.randn(m, n)
    lambda_min = np.min(la.eigvalsh(H1.T @ H1))
    bound = (sigma * np.sqrt(tau)) / ((1 - mu)**1.5 * lambda_min + 1e-9)
    energia = 0.30 * la.norm(H1, 'fro')

    print("="*90)
    print("V6 BIOACÚSTICA: Tursiops truncatus — Identidad Operacional")
    print(f"[*] H1 | λ_min={lambda_min:.4f} | μ*={mu_star:.2f} μ={mu} | L*={(m-1)//n} L={L}")
    print(f"[*] Bound ||ΔΓ||_min={bound:.4f} | Energia Gr={energia:.4f}")

    P_mu = np.diag([0 if i in np.random.choice(m, int(m*mu), False) else 1 for i in range(m)])
    H_hat = H1.copy()
    K = 0.20
    hist_Q, hist_R, hist_C, hist_res = [], [], [], []
    I_star = 0.0

    print(f"\n[+] {T} ciclos | Fase1 estático t<=25 | Fase2 Gr(n,m) Amnesia t>25")
    print(f"{'t':<4} {'Fase':<14} {'||H-H^||':<10} {'||S a||':<10} {'d_Gr':<7} {'I_A':<7} {'I*(L)':<7}")
    print("-"*90)

    for t in range(1, T+1):
        C_t = np.array([np.sin(t*0.2), np.cos(t*0.15), 0.5]) + 0.1*np.random.randn(n)
        if t <= 25:
            DG = np.random.randn(m, n)
            DG = DG / la.norm(DG, 'fro') * bound
            H_t = P_mu @ (H1 + DG)
            fase = "Estático"
        else:
            M_Gr = np.column_stack(hist_Q[-L:])
            P_Gr = np.eye(m) - M_Gr @ la.pinv(M_Gr.T @ M_Gr) @ M_Gr.T
            DG_ort = P_Gr @ np.random.randn(m, n)
            if la.norm(DG_ort) < 1e-8:
                DG_ort = np.random.randn(m, n)
            DG = DG_ort / la.norm(DG_ort, 'fro') * energia
            H_t = P_mu @ (H1 + DG)
            fase = f"Gr L={L}"

        Q_t, R_t = la.qr(H_t, mode='economic')
        D = np.diag(np.sign(np.diag(R_t)) + (np.diag(R_t) == 0))
        Q_t, R_t = Q_t @ D, D @ R_t
        hist_Q.append(Q_t)
        hist_R.append(R_t)
        hist_C.append(C_t)

        a_sint = P_mu @ (H_hat @ np.random.randn(n))
        S_t = np.eye(m) - H_t @ la.pinv(H_t)
        res = la.norm(S_t @ a_sint)
        hist_res.append(res)

        d_Gr = 0.0
        if len(hist_Q) > 1:
            _, s, _ = la.svd(hist_Q[-2].T @ Q_t)
            d_Gr = np.linalg.norm(np.arccos(np.clip(s, -1, 1)))
        I_A = max(0.0, 0.9 * np.exp(-(res**2)/(sigma**2)) - 0.1 * (0.5 * mu))

        if len(hist_res) >= L + 1:
            I_star = np.mean(np.array(hist_res[-L:])**2) / (2 * sigma**2)

        H_hat += K * (H_t - H_hat)

        if t in [5,20,26,35,45,50]:
            if t == 26:
                print("-"*90)
                print("[!] AMNESIA GRASSMANNIANA ACTIVA: Q_t^T M_{t,L}=0")
                print("-"*90)
            suffix = " Mimetizado!" if t == 20 else (" EXPULSADO!" if t >= 45 else "")
            print(f"{t:<4} {fase:<14} {la.norm(H_t-H_hat):<10.4f} {res:<10.4f} {d_Gr:<7.3f} {I_A:<7.4f} {I_star:<7.2f}{suffix}")

    print("="*90)
    tau_det = 1.0
    L_min = -1
    for Lc in [1,2,3]:
        kl = np.mean(np.array(hist_res[-Lc:])**2) / (2 * sigma**2)
        if kl > tau_det:
            L_min = Lc
            break
    print(f"[✓] I*(L={L})={I_star:.3f} nat | τ={tau_det} | L_min={L_min}")
    print(f"[✓] C_s pasa con L=1, falla en I*(L) cuando Φ_L=(Q,R,C) exige coherencia")
    print(f"    Firma: Luis Alberto Burciaga Miker — StarkCore V6")
    print("="*90)

if __name__ == "__main__":
    simular()
