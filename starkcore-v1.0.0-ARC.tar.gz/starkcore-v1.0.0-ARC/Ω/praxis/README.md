# Π Praxis

Dominio de la ejecución.

Aquí viven las implementaciones.

Ejemplos:

- Core
- Experimentos
- Benchmarks
- Laboratorio
- Tooling

Π responde:

¿Cómo ocurre?
