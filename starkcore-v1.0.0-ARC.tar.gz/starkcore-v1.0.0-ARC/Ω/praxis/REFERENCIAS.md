# Referencias Praxis

Este dominio apunta a las implementaciones.

Ubicación principal:

- experiments/
- core/
- starkcore_concurrent/
- lab/

Aquí las ideas se transforman en código, protocolos y experimentos.
