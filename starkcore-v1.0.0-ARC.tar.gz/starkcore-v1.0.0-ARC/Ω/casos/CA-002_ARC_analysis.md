# ARC Case Study — CA-002
## Falacia de Identidad Mutable

### Método aplicado
ARC v1.1 — Alineamiento de Resonancia y Condiciones

**Caso:** CA-002  
**Categoría:** Integridad de identidad en sistemas de software  
**Estado:** Análisis metodológico

---

# 0. Contexto

CA-002 describe una falla donde un identificador aparentemente estable no garantiza que el objeto asociado permanezca idéntico a través del tiempo.

Ejemplo conceptual:


La etiqueta permanece.
El contenido cambia.

---

# 1. Principio ARC aplicado

La resistencia del sistema no estaba en la ausencia de información.

La resistencia estaba en una condición incorrecta de identificación.

El sistema confiaba en una representación externa:


cuando la identidad real requería:


---

# 2. Identificación de ω₀

## Invariante buscada

La propiedad que el sistema debía conservar:


ω₀:


---

# 3. Identificación de ωᵢ

La intervención existente:


El sistema asumía:


---

# 4. Desalineación ARC

Estado:


La etiqueta describía una identidad.

El contenido demostraba otra.

La resistencia apareció porque el modelo de identidad no estaba alineado con la propiedad que debía proteger.

---

# 5. Matriz ARC

| | Barrera baja | Barrera alta |
|-|-|-|
| Conozco ω₀ | A | B |
| No conozco ω₀ | C | D |

Aplicación:


---

# 6. Intervención articulada

Impacto:

Crear listas de excepciones basadas en nombres.

Problema:

La etiqueta puede cambiar sin revelar el cambio.

---

Articulación:

Anclar la identidad al objeto verificable:

La identidad deja de depender de una declaración externa.

---

# 7. Resultado observado

Cambio conceptual:

Antes:

Después:


---

# 8. Observación ARC

CA-002 muestra una posible aplicación del principio:

La falla no estaba en la falta de fuerza de validación.

Estaba en validar la variable equivocada.

---

# 9. Criterio de revisión

Este análisis sería insuficiente si un sistema pudiera demostrar que una identidad basada únicamente en etiquetas mantiene reproducibilidad bajo modificaciones arbitrarias del contenido.

La hipótesis permanece abierta a refutación.

---

Fin del caso CA-002 / ARC v1.1

