# Ω

Ω no es un módulo.

Ω es el mapa conceptual del proyecto.

Todo artefacto pertenece simultáneamente a tres dominios:

├── Logos
│   Ideas, modelos, axiomas y teoría.
│
├── Praxis
│   Implementaciones, protocolos y experimentos.
│
└── Mnemosyne
    Evidencia, memoria, historia y representación.

Un mismo trabajo puede existir en los tres dominios.

Ejemplo:

Axioma XV

    Logos
        formulación matemática

    Praxis
        implementación STARDARK Passport

    Mnemosyne
        poema
        partitura
        evidencia histórica

El recorrido natural del proyecto es:

Logos
   ↓
Praxis
   ↓
Mnemosyne

Y toda nueva evidencia alimenta nuevamente a Logos.

Ω es un ciclo, no una línea.
