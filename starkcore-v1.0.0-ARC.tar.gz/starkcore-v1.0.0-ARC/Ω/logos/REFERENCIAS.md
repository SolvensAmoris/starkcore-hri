# Referencias Logos

Este dominio apunta a la teoría del proyecto.

Ubicación principal:

- docs/
- WHITE_PAPER_STARDARK.md
- CONTRATO_0_MATH.md
- STARDARK_TESTIMONIO_v2_2.md

Las ideas nacen aquí antes de convertirse en implementación.
