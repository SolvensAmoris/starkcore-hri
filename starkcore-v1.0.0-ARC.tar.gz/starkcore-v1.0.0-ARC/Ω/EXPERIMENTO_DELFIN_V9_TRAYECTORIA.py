"""
StarkCore V9 — HSIC sobre Φ_L trayectoria completa
Autor: Luis Alberto Burciaga Miker
Corrige V8:
- L=1 no válido con HSIC estándar (N>=4)
- L_opt con nan-safe max
- I*(L)=HSIC(Φ^Q_{t-L:t}, Φ^R_{t-L:t}, Φ^C_{t-L:t}) -> kernel ve historia, no fotograma
Teorema: Estado≠Trayectoria≠Proceso Generador
"""
import numpy as np, scipy.linalg as la
np.random.seed(42)

def rbf_kernel(X, sigma=None):
    sq = np.sum(X**2,1)[:,None] + np.sum(X**2,1)[None,:] - 2*X@X.T
    if sigma is None:
        # median heuristic robusto
        vals = sq[np.triu_indices_from(sq,1)]
        sigma = np.median(vals)**0.5 + 1e-6 if len(vals)>0 else 1.0
    return np.exp(-sq/(2*sigma**2+1e-12))

def hsic(K,L):
    n=K.shape[0]
    if n<4: return np.nan # <- guardia V8
    H = np.eye(n) - np.ones((n,n))/n
    return np.trace(K @ H @ L @ H) / ((n-1)**2)

n,m,T = 3,10,120

def gen_real(T):
    H = np.random.randn(m,n)
    feats=[]
    for t in range(T):
        eta = np.random.randn(n) # causa común
        # dependencia NO LINEAL Y=X^2
        H = H + 0.08*np.outer(np.random.randn(m), np.tanh(eta))
        Q,R = la.qr(H, mode='economic')
        R = R @ np.diag(1+0.3*eta**2)
        C = np.sin(eta*2.1) + 0.05*np.random.randn(n)
        feats.append(np.concatenate([Q[:,0], np.diag(R), C]))
    return np.array(feats)

def gen_sint(T):
    feats=[]
    for t in range(T):
        Q,_ = la.qr(np.random.randn(m,n), mode='economic')
        R = np.diag(np.random.randn(n))
        C = np.random.randn(n)
        feats.append(np.concatenate([Q[:,0], np.diag(R), C]))
    return np.array(feats)

real = gen_real(T)
sint = gen_sint(T)

def trajectory_hsic(feats, L):
    """V9: Φ_L = concat de L pasos -> un vector por ventana"""
    if L<2: return np.nan, np.nan, np.nan
    # Construir N trayectorias: cada muestra es Φ_{t-L:t} aplanado
    trajs=[]
    for i in range(len(feats)-L):
        trajs.append(feats[i:i+L].reshape(-1)) # dim = L*9
    trajs = np.array(trajs) # N x (L*9)
    N = trajs.shape[0]
    if N<10: return np.nan, np.nan, np.nan
    # Split trayectoria en 3 canales temporales
    # Cada canal conserva historia: Q_traj, R_traj, C_traj
    dim = 3
    Q_traj = trajs[:, :L*dim] # historia de Q
    R_traj = trajs[:, L*dim:2*L*dim] # historia de R
    C_traj = trajs[:, 2*L*dim:] # historia de C
    Kq = rbf_kernel(Q_traj)
    Kr = rbf_kernel(R_traj)
    Kc = rbf_kernel(C_traj)
    # I* = HSIC(Q,R) + HSIC(R,C) sobre trayectorias
    return hsic(Kq,Kr), hsic(Kr,Kc), N

print("="*95)
print("V9 — HSIC(Φ_{t-L:t}) — la película, no fotogramas")
print("="*95)
print(f"{'L':<4} {'N_traj':<8} {'HSIC_QR_real':<14} {'HSIC_QR_sint':<14} {'Δ_QR':<10} {'L_opt'}")
print("-"*95)

results=[]
for L in [1,2,3,5,10,20,30,40]:
    hr_qr, hr_rc, N = trajectory_hsic(real, L)
    hs_qr, hs_rc, _ = trajectory_hsic(sint, L)
    if np.isnan(hr_qr):
        print(f"{L:<4} {'-':<8} {'nan':<14} {'nan':<14} {'no medible':<10} (N<4)")
        continue
    delta = hr_qr - hs_qr
    results.append((L, delta, hr_qr, hs_qr, N))

if results:
    # nan-safe max
    L_opt, d_opt, _, _, _ = max(results, key=lambda x: x[1])
    for L, delta, hr, hs, N in results:
        mark = "<-- L_opt / L_min" if L==L_opt else ""
        print(f"{L:<4} {N:<8} {hr:<14.5f} {hs:<14.5f} {delta:<10.5f} {mark}")
    print("-"*95)
    print(f"[✓] L=1 no medible (HSIC requiere N>=4)")
    print(f"[✓] Ventana óptima no monotónica: L_opt={L_opt} con Δ={d_opt:.5f}")
    print(f"[✓] Más memoria ≠ más identidad. Hay escala temporal de la huella causal.")

print("="*95)
print("V1→V9:")
print("V1 estado engaña | V2 μ*,L* inválidos | V3 Cs pasa | V4 gemelo geométrico")
print("V5 costes locales | V6 Sa=0 tautológico | V7 I(Q;R) y L no monotónico")
print("V8 HSIC no lineal | V9 HSIC(Φ_L) trayectoria completa")
print("Teorema: Estado≠Trayectoria≠Proceso Generador")
print("Firma: Luis Alberto Burciaga Miker — StarkCore V9")
print("="*95)
