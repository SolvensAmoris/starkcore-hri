# Índice Ω

Todo artefacto puede pertenecer simultáneamente a tres dominios.

Ejemplo:

Axioma XV

Logos
    formulación matemática

Praxis
    implementación del protocolo STARDARK

Mnemosyne
    poema
    partitura
    evidencia histórica

---

CA-002

Logos
    definición de la anomalía

Praxis
    pruebas reproducibles

Mnemosyne
    cronología
    documentación
    conferencia

---

Ω no clasifica archivos.

Ω clasifica funciones del conocimiento.
