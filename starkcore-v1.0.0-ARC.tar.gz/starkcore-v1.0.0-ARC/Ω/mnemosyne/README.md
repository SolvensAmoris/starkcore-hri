# Mnemosyne

Dominio de la memoria.

Nada aquí crea teoría.

Nada aquí ejecuta algoritmos.

Aquí permanece el linaje del proyecto.

Subdominios:

- Evidencia
- Attestations
- Archivo
- Poesía Invariante
- Música
- Visual Bible

Mnemosyne responde:

¿Cómo sabemos que ocurrió?
