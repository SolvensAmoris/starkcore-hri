# Referencias Mnemosyne

Este dominio apunta a la memoria verificable.

Ubicación principal:

- evidence/
- poesia_invariante/
- STARDARK_ATTESTATION.json

Aquí permanece el linaje verificable del proyecto.
