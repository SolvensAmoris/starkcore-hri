# Registro de entorno de captura

## Dispositivo de ejecución

Equipo utilizado durante la captura de evidencia experimental:

- Fabricante: HUAWEI
- Modelo: nova 5T
- Identificador de modelo: YAL-L21
- Proyecto asociado: StarkCore Lab

## Sistema

- Compilación: 12.0.0.165(C605E6R1P2)
- EMUI: 12.0.0
- Android: entorno móvil de ejecución
- Arquitectura: aarch64

## Hardware

- Procesador: Huawei Kirin 980
- RAM: 8 GB

## Kernel y seguridad

- Kernel: 4.14.116
- Fecha kernel: Tue Nov 15 2022
- Parche de seguridad Android: 1 Nov 2022
- Actualización Mainline: 2019-09

## Identificación adicional

- Versión de hardware: HL2YALEM01
- Personalización: CUSTC605D1
- Parámetros/Zona horaria: TB.GENC.1.10.25.100

## Estado durante captura

- Batería: 34%
- Estado carga: No cargando
- Tiempo de ejecución: 18:10:08

## Nota metodológica

Este documento conserva las condiciones del dispositivo en el momento
de captura de evidencia.

No representa una modificación del entorno original ni una condición
necesaria para reproducir el sistema.

Clasificación:
CONTEXTO DE EJECUCIÓN HISTÓRICO.
