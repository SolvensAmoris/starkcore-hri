# Contributor Covenant Code of Conduct

## Our Pledge
We pledge to make participation in StarkCore a harassment-free experience for everyone, regardless of background.

We are a defensive security research lab. We focus on evidence, integrity, and reproducibility.

## Our Standards
Examples of behavior that contributes to a positive environment:
- Defensive-first contributions
- Providing evidence chain S(C0) -> Merkle -> OTS for changes
- Respectful reviews, focusing on evidence over assumption
- Responsible disclosure

Examples of unacceptable behavior:
- Publishing exploit kits, malware, or instructions for unauthorized access
- Harassment, doxxing, or discriminatory language
- Submitting code that circumvents authentication without authorization context

## Enforcement
Instances of abusive behavior may be reported to security@starkcore.lab
All complaints will be reviewed and investigated promptly.

## Attribution
This Code of Conduct is adapted from the Contributor Covenant, version 2.1,
available at https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
