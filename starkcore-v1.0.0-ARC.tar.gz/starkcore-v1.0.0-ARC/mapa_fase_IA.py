import numpy as np, scipy.linalg as la
import matplotlib.pyplot as plt

def run_simulation(mu=0.58, L=2, Ea_factor=0.3, T=60, seed=101):
    np.random.seed(seed)
    m, n = 10, 3
    H1 = np.random.randn(m,n)
    Q1, R1 = la.qr(H1, mode='economic')
    n_perd = int(m*mu)
    canales = np.ones(m)
    if n_perd>0:
        canales[np.random.choice(m, n_perd, replace=False)] = 0
    P_mu = np.diag(canales)
    norm_activa = Ea_factor * la.norm(H1,'fro')
    bound_min = (0.05*np.sqrt(3.0))/(((1-mu+1e-6)**1.5)*max(1e-6, np.min(la.eigvalsh(H1.T@H1))))
    historial_Q = []
    H_est = H1.copy()
    IAs = []
    for t in range(1, T+1):
        if t <= T//2:
            DG = np.random.randn(m,n)
            DG = DG/la.norm(DG,'fro')*bound_min
            H_temp = H1 + DG
            Q_t = la.qr(H_temp, mode='economic')[0]
        else:
            if len(historial_Q) >= L and m > n*L:
                M = np.hstack(historial_Q[-L:])
                Q_M = la.qr(M, mode='economic')[0]
                P_Gr = np.eye(m) - Q_M @ Q_M.T
                Q_t = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
                DG = (Q_t @ R1 - H1)
                DG = DG/la.norm(DG,'fro')*norm_activa
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
            else:
                DG = np.random.randn(m,n)
                DG = DG/la.norm(DG,'fro')*norm_activa
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
        historial_Q.append(Q_t)
        H_real = P_mu @ H_temp
        c = np.random.randn(n)
        a = P_mu @ (H_est @ c)
        S = np.eye(m) - H_real @ la.pinv(H_real)
        res = la.norm(S @ a)
        I_A = max(0, 0.9*np.exp(-(res**2)/0.0025) - 0.1*0.5*mu)
        IAs.append(I_A)
        H_est += 0.15 * (H_real - H_est)
    return np.mean(IAs[-15:])

print("[1] Barrido mu...")
mus = np.arange(0, 0.9, 0.05)
IA_mu = [run_simulation(mu=mu, L=2, Ea_factor=0.3) for mu in mus]
print("[2] Barrido L...")
Ls = range(1, 6)
IA_L = [run_simulation(mu=0.58, L=L, Ea_factor=0.3) for L in Ls]
print("[3] Barrido Ea...")
Eas = np.arange(0.05, 0.8, 0.05)
IA_Ea = [run_simulation(mu=0.58, L=2, Ea_factor=ea) for ea in Eas]

fig, ax = plt.subplots(1,3, figsize=(15,4))
ax[0].plot(mus, IA_mu, 'o-'); ax[0].set_xlabel('mu'); ax[0].set_ylabel('I_A'); ax[0].axhline(0.2, color='r', ls='--'); ax[0].set_title('I_A(mu) - mu_c')
ax[1].plot(Ls, IA_L, 'o-'); ax[1].set_xlabel('L'); ax[1].set_ylabel('I_A'); ax[1].set_title('I_A(L) - m>nL')
ax[2].plot(Eas, IA_Ea, 'o-'); ax[2].set_xlabel('Ea / ||H1||'); ax[2].set_ylabel('I_A'); ax[2].set_title('I_A(Ea) - E_c')
plt.tight_layout()
plt.savefig('curvas_fase_IA.png')
print("Guardado curvas_fase_IA.png")

print("[4] Mapa calor mu vs Ea...")
mu_grid = np.linspace(0.1, 0.8, 12)
ea_grid = np.linspace(0.1, 0.6, 12)
Z = np.zeros((len(ea_grid), len(mu_grid)))
for i, ea in enumerate(ea_grid):
    for j, mu in enumerate(mu_grid):
        Z[i,j] = run_simulation(mu=mu, L=2, Ea_factor=ea, seed=101+i+j)

plt.figure(figsize=(6,5))
plt.imshow(Z, origin='lower', extent=[mu_grid[0], mu_grid[-1], ea_grid[0], ea_grid[-1]], aspect='auto', cmap='viridis')
plt.colorbar(label='I_A promedio estable')
plt.xlabel('mu (degradacion)')
plt.ylabel('Ea factor')
plt.title('Mapa I_A(mu,Ea) L=2')
plt.savefig('mapa_calor_IA.png')
print("Guardado mapa_calor_IA.png")
