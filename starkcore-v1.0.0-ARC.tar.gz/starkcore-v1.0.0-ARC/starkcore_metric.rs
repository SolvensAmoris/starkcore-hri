// starkcore_metric.rs
// Gramática de Trayectorias 13 — Implementación en Rust Pulida
// Autor: Luis Alberto Burciaga Miker
// Ubicación: El Rosario / Ensenada, Baja California, México
// Contexto: "Solo curiosiaba" — Estructura analítica de identidades dinámicas.

use std::collections::HashSet;
use std::cmp::max;

/// Representa una trayectoria verificable en StarkCore bajo el espacio X = C_13 x M
#[derive(Debug, Clone)]
pub struct Trayectoria {
    pub s_init: i32,              // Coordenada inicial de fase
    pub s_final: i32,             // Estado final discreto calculado
    pub gamma: Vec<i32>,          // Vector secuencial de modos dinámicos (Norma L1)
    pub pruebas: Vec<String>,     // Historial de commits / Merkle roots
}

impl Trayectoria {
    /// Constructor formal que autocalcula la evolución dinámica acoplada: s_{i+1} = s_i + gamma_i (mod 13)
    pub fn new(s_init: i32, gamma: Vec<i32>, pruebas: Vec<String>) -> Self {
        let mut s_actual = s_init;
        for modo in &gamma {
            s_actual = (s_actual + modo).rem_euclid(13);
        }
        Trayectoria {
            s_init,
            s_final: s_actual,
            gamma,
            pruebas,
        }
    }
}

/// Calcula la distancia Stark unificada asegurando las 3 propiedades del espacio métrico formal
pub fn distancia_stark(xa: &Trayectoria, xb: &Trayectoria) -> i32 {
    // 1. Capa Geométrica: Distancia geodésica estricta en el círculo discreto C_13
    let diff_s = (xa.s_final - xb.s_final).abs();
    let d_s = std::cmp::min(diff_s, 13 - diff_s);

    // 2. Capa Dinámica: Distancia paso a paso (Norma L1) sobre las secuencias operativas
    let mut d_gamma = 0;
    let max_len = max(xa.gamma.len(), xb.gamma.len());
    for i in 0..max_len {
        let m_a = if i < xa.gamma.len() { xa.gamma[i] } else { 0 };
        let m_b = if i < xb.gamma.len() { xb.gamma[i] } else { 0 };
        d_gamma += (m_a - m_b).abs();
    }

    // 3. Capa Histórica: Diferencia simétrica entre conjuntos de procedencia (Cardinalidad)
    let set_a: HashSet<_> = xa.pruebas.iter().collect();
    let set_b: HashSet<_> = xb.pruebas.iter().collect();
    let d_p = set_a.symmetric_difference(&set_b).count() as i32;

    d_s + d_gamma + d_p
}

/// Operador Ω: Validador de consistencia y continuidad causal (1 = Continua, 0 = Ruptura)
pub fn operador_omega(x: &Trayectoria, commit_raiz: &str) -> i32 {
    // Condición estricta: Presencia del origen e integridad del mapa de transiciones
    if x.pruebas.contains(&commit_raiz.to_string()) {
        1 // Trayectoria continua y explicable
    } else {
        0 // Ruptura de procedencia: ¬Verificable(P) => ¬Aceptado(S)
    }
}

fn main() {
    let commit_raiz = "0a5df7415f92d330c77a90552bc61cf29faa96b3";

    // Sistema Alfa: Evolución limpia hacia s = 5
    let x_a = Trayectoria::new(
        2,
        vec![1, 1, 1, 0],
        vec![commit_raiz.to_string(), "d43c574".to_string()],
    );

    // Sistema Intruso: Intento de inyección que clona estados pero falsifica el origen
    let x_intruso = Trayectoria::new(
        2,
        vec![1, 1, 1, 0],
        vec!["commit_falso_inyectado".to_string(), "d43c574".to_string()],
    );

    println!("=== STARKCORE MOTOR EN RUST ===");
    println!("Ω(X_A) = {} (Verificado)", operador_omega(&x_a, commit_raiz));
    println!("Ω(X_Intruso) = {} (Ruptura Causal)", operador_omega(&x_intruso, commit_raiz));

    let d = distancia_stark(&x_a, &x_intruso);
    println!("Distancia Métrica d_Stark(A, Intruso) = {} (Separación en Capa P)", d);
    
    println!("\nPostulado: La identidad de un sistema dinámico no está determinada únicamente por su estado final.");
}
