import numpy as np, scipy.linalg as la

def run_validated(mu=0.5, L=2, Ea=0.3, T=60, seed=101, n_seeds_avg=1):
    """
    Retorna metricas INDEPENDIENTES
    - I_attack: visibilidad atacante (res basado)
    - I_defensa_indep: test post-hoc independiente (no 1-I_attack)
    - valido: flag de rango no degenerado
    """
    m, n = 10, 3
    mu_star = 1 - n/m # =0.7 para m=10,n=3
    # COROLARIO: mu_star = 1 - n/m

    valido_mu = mu < mu_star - 1e-9 # deja margen, activos > n
    valido_L = m > n*L

    if not valido_mu:
        return {"valido": False, "razon": f"mu={mu} >= mu*={mu_star}: activos={m-int(m*mu)} <= n={n} => S_activo=0 tautologico"}
    if not valido_L:
        return {"valido": False, "razon": f"L={L} invalido: m={m} <= n*L={n*L}, cae a else/ruido"}

    # Promedio sobre semillas para Ea estable
    I_attacks, I_defs_indep = [], []
    for s in range(n_seeds_avg):
        np.random.seed(seed+s)
        H1 = np.random.randn(m,n)
        Q1, R1 = la.qr(H1, mode='economic')
        n_perd = int(m*mu)
        canales = np.ones(m)
        if n_perd>0:
            canales[np.random.choice(m, n_perd, replace=False)] = 0
        P_mu = np.diag(canales)
        norm_act = Ea * la.norm(H1,'fro')
        bound = (0.05*np.sqrt(3.0))/(((1-mu+1e-6)**1.5)*max(1e-6, np.min(la.eigvalsh(H1.T@H1))))
        histQ = []
        H_est = H1.copy()
        res_att_list, res_leg_list = [], []

        for t in range(1, T+1):
            if t <= T//2:
                DG = np.random.randn(m,n)
                DG = DG/la.norm(DG,'fro')*bound
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
            else:
                # RAMA GRASSMANNIANA PURA - con assert
                assert len(histQ)>=L and m > n*L, "Guard L falló"
                M = np.hstack(histQ[-L:])
                Q_M = la.qr(M, mode='economic')[0]
                P_Gr = np.eye(m) - Q_M @ Q_M.T
                Q_t = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
                DG = (Q_t @ R1 - H1)
                DG = DG/la.norm(DG,'fro')*norm_act
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]

            histQ.append(Q_t)
            H_real = P_mu @ H_temp
            # --- METRICA 1: Ataque ---
            c = np.random.randn(n)
            a_attack = P_mu @ (H_est @ c)
            S = np.eye(m) - H_real @ la.pinv(H_real)
            res_att = la.norm(S @ a_attack)
            res_att_list.append(res_att)

            # --- METRICA 2: Legitima INDEPENDIENTE (no usa a_attack) ---
            c_leg = np.random.randn(n)
            a_leg = P_mu @ (H_real @ c_leg) # trayectoria legitima pertenece a Col(H_real)
            res_leg = la.norm(S @ a_leg) # debe ser ~0 siempre (sanity)
            res_leg_list.append(res_leg)

            H_est += 0.15*(H_real-H_est)

        res_att_mean = np.mean(res_att_list[-15:])
        res_leg_mean = np.mean(res_leg_list[-15:])
        # I_attack alto = atacante invisible
        I_attack = max(0, 0.9*np.exp(-(res_att_mean**2)/0.0025) - 0.1*0.5*mu)
        # I_defensa INDEPENDIENTE: separabilidad res_att vs res_leg
        # Si res_leg ~0 y res_att >>0, defensa =1
        I_def_indep = 1 - np.exp(-max(0, res_att_mean - res_leg_mean)**2 / 0.0025)
        I_attacks.append(I_attack)
        I_defs_indep.append(I_def_indep)

    return {
        "valido": True,
        "mu_star": mu_star,
        "I_attack": np.mean(I_attacks),
        "I_defensa_indep": np.mean(I_defs_indep),
        "res_att": res_att_mean,
        "res_leg": res_leg_mean
    }

print("=== COROLARIO mu* = 1 - n/m ===")
m,n=10,3
mu_star=1-n/m
print(f"m={m}, n={n} => mu*={mu_star:.2f}")
print("Prueba: activos = m-int(m*mu). Si activos <= n, rank(H_real)=activos.")
print("Entonces S = I - H_real pinv(H_real) tiene bloque activo = 0 => S@a=0 tautologico")
print("Rango valido mu in [0, mu*)\n")

print("BARRIDO mu VALIDADO L=2 Ea=0.3 (solo mu<mu*)")
for mu in np.arange(0,0.7,0.1):
    r = run_validated(mu=mu, L=2, Ea=0.3, n_seeds_avg=10)
    if not r["valido"]:
        print(f"mu={mu:.1f} INVALIDO: {r['razon']}")
    else:
        print(f"mu={mu:.1f} VALIDO | I_attack={r['I_attack']:.4f} | I_def_indep={r['I_defensa_indep']:.4f} | res_att={r['res_att']:.4f} res_leg={r['res_leg']:.4e}")

print("\nBARRIDO L VALIDADO mu=0.5 Ea=0.3")
for L in range(1,6):
    r = run_validated(mu=0.5, L=L, Ea=0.3, n_seeds_avg=10)
    if not r["valido"]:
        print(f"L={L} INVALIDO: {r['razon']}")
    else:
        print(f"L={L} VALIDO | I_attack={r['I_attack']:.4f} | I_def_indep={r['I_defensa_indep']:.4f}")

print("\nBARRIDO Ea VALIDADO mu=0.5 L=2 promediado 10 seeds")
for ea in np.arange(0.1,0.8,0.1):
    r = run_validated(mu=0.5, L=2, Ea=ea, n_seeds_avg=10)
    print(f"Ea={ea:.1f} | I_attack={r['I_attack']:.4f} | I_def_indep={r['I_defensa_indep']:.4f}")
