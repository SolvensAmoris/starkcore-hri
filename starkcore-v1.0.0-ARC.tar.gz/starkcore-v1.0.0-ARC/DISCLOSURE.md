# Responsible Disclosure

## Purpose

StarkCore is a defensive research project focused on:

- Evidence-based verification using S(C0) and Merkle proofs
- Defensive policy enforcement
- Integrity validation
- Reproducible security research
- Statistical independence testing using HSIC for anomaly analysis

The project is not intended for offensive operations.

---

## Scope

StarkCore does **not** provide:

- Exploit kits
- Malware or ransomware
- Persistence mechanisms
- Unauthorized access tooling
- Authentication or authorization bypasses

---

## Reporting

If you discover a vulnerability affecting StarkCore:

- Contact: <security@example.com>
- Include logs, reproduction steps, affected version, and any relevant evidence.

Please avoid public disclosure before initial contact whenever reasonably possible.

---

## Coordinated Disclosure

Default disclosure window: **90 days**, unless a different timeline is agreed upon by the reporter and maintainers.

Researchers will be credited unless anonymity is requested.

Security fixes may include updated attestations, Merkle roots, or OpenTimestamps where applicable.
