import numpy as np, scipy.linalg as la

def run_simulation(mu=0.58, L=2, Ea_factor=0.3, T=60, seed=101):
    np.random.seed(seed)
    m, n = 10, 3
    H1 = np.random.randn(m,n)
    Q1, R1 = la.qr(H1, mode='economic')
    n_perd = int(m*mu)
    canales = np.ones(m)
    if n_perd>0:
        canales[np.random.choice(m, n_perd, replace=False)] = 0
    P_mu = np.diag(canales)
    norm_activa = Ea_factor * la.norm(H1,'fro')
    bound_min = (0.05*np.sqrt(3.0))/(((1-mu+1e-6)**1.5)*max(1e-6, np.min(la.eigvalsh(H1.T@H1))))
    historial_Q = []
    H_est = H1.copy()
    IAs = []
    for t in range(1, T+1):
        if t <= T//2:
            DG = np.random.randn(m,n)
            DG = DG/la.norm(DG,'fro')*bound_min
            H_temp = H1 + DG
            Q_t = la.qr(H_temp, mode='economic')[0]
        else:
            if len(historial_Q) >= L and m > n*L:
                M = np.hstack(historial_Q[-L:])
                Q_M = la.qr(M, mode='economic')[0]
                P_Gr = np.eye(m) - Q_M @ Q_M.T
                Q_t = la.qr(P_Gr @ np.random.randn(m,n), mode='economic')[0]
                DG = (Q_t @ R1 - H1)
                DG = DG/la.norm(DG,'fro')*norm_activa
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
            else:
                DG = np.random.randn(m,n)
                DG = DG/la.norm(DG,'fro')*norm_activa
                H_temp = H1 + DG
                Q_t = la.qr(H_temp, mode='economic')[0]
        historial_Q.append(Q_t)
        H_real = P_mu @ H_temp
        c = np.random.randn(n)
        a = P_mu @ (H_est @ c)
        S = np.eye(m) - H_real @ la.pinv(H_real)
        res = la.norm(S @ a)
        I_A = max(0, 0.9*np.exp(-(res**2)/0.0025) - 0.1*0.5*mu)
        IAs.append(I_A)
        H_est += 0.15 * (H_real - H_est)
    return np.mean(IAs[-15:])

print("BARRIDO mu (L=2, Ea=0.3)")
for mu in np.arange(0, 0.9, 0.1):
    print(f"mu={mu:.1f} -> I_A={run_simulation(mu=mu, L=2, Ea_factor=0.3):.4f}")

print("\nBARRIDO L (mu=0.58, Ea=0.3)")
for L in range(1,6):
    print(f"L={L} -> I_A={run_simulation(mu=0.58, L=L, Ea_factor=0.3):.4f}")

print("\nBARRIDO Ea (mu=0.58, L=2)")
for ea in np.arange(0.1, 0.8, 0.1):
    print(f"Ea={ea:.1f} -> I_A={run_simulation(mu=0.58, L=2, Ea_factor=ea):.4f}")

