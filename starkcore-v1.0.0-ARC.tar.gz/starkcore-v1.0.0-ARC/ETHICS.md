# Ethical Principles

StarkCore exists to improve software integrity through verifiable evidence.

## Principles

1. Defensive-first.
2. Evidence over assumption.
3. Reproducibility.
4. Responsible disclosure.
5. Respect for authorization boundaries.
6. Transparency regarding assumptions and limitations.

Research and testing should be performed only on systems owned by the researcher or where explicit authorization has been granted.

HSIC-based analyses provide statistical evidence and should not be interpreted as absolute proof in isolation.

This work is inspired by open scientific practice and kernel-based statistical methods, including Gretton et al.
