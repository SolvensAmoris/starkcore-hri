# Estructura del Repositorio StarkCore

Este repositorio organiza el conocimiento en capas independientes.

## Core

Implementación del sistema.

## Docs

Contiene únicamente documentación técnica.

- Axiomas
- Definiciones
- Teoremas
- Modelos
- Protocolos
- Whitepapers

## Evidence

Resultados reproducibles.

- Experimentos
- Benchmarks
- Attestations

## Lab

Trabajo en progreso.

Nada dentro de Lab constituye una especificación oficial hasta migrarse a Docs.

## Poesía Invariante

Representaciones artísticas inspiradas en StarkCore.

No forman parte de la especificación normativa.

## Principio

Cada concepto debe poseer un lugar único dentro del repositorio.

La organización también constituye evidencia.
