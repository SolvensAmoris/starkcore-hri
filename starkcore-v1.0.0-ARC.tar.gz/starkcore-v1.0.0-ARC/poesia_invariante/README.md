# Poesía Invariante

Esta carpeta reúne composiciones inspiradas en los formalismos de StarkCore y STARDARK.

Cada obra nace de una especificación técnica o de un experimento, pero no forma parte de la especificación normativa.

Objetivos:

- Explorar representaciones artísticas de conceptos formales.
- Traducir axiomas y modelos a lenguaje poético y musical.
- Mantener separada la documentación técnica de la interpretación creativa.

La autoría técnica y la autoría artística pueden coincidir, pero cumplen funciones distintas dentro del proyecto.
