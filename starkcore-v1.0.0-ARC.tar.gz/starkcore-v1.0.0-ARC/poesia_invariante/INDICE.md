# Índice · Poesía Invariante

## Axiomas

- Axioma 0
- Axioma XV

## Anomalías

- CA-002

## Operadores

- Ω

Cada obra representa una interpretación artística inspirada en los formalismos de StarkCore y STARDARK.

No sustituye las especificaciones técnicas ni constituye documentación normativa.
