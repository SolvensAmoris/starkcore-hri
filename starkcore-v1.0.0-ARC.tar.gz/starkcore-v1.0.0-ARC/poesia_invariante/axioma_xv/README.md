# Axioma XV — Testimonio del Salto

Contenido esperado:

- poema.md
- partitura.ly
- partitura.mid
- audio/
- referencias.md

Estado:
En desarrollo.
