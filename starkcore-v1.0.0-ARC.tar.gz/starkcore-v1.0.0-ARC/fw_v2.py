import socket, threading, yaml, time

with open("firewall.yaml") as f:
    CFG = yaml.safe_load(f)

BLOCKED = set(CFG["blocked_ips"])
ALLOW_PORTS = set(CFG["allow_ports"])

# ESTA ES TU BASE MATEMÁTICA - F(p)
def F(p_ip, p_port):
    return (p_ip not in BLOCKED) and (p_port in ALLOW_PORTS)

def handle(client, addr):
    ip = addr[0]
    verdict = "ALLOW" if F(ip, 8888) else "DROP"
    print(f"[{time.strftime('%H:%M:%S')}] {ip} -> {verdict} | F(p)={F(ip,8888)}")
    client.close()

s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("0.0.0.0", 9090))
s.listen(100)
print(f"FW as Code V2 | ALLOW={ALLOW_PORTS} | BLOCKED={BLOCKED}")
print("Escuchando en 0.0.0.0:9090 - Prueba desde otra terminal: curl 127.0.0.1:9090")
while True:
    c,a = s.accept()
    threading.Thread(target=handle, args=(c,a), daemon=True).start()
