// src/lib.rs
// StarkCore Core Metrics Library
use std::collections::HashSet;
use std::cmp::max;

#[derive(Debug, Clone)]
pub struct Trayectoria {
    pub s_init: i32,
    pub s_final: i32,
    pub gamma: Vec<i32>,
    pub pruebas: Vec<String>,
}

impl Trayectoria {
    pub fn new(s_init: i32, gamma: Vec<i32>, pruebas: Vec<String>) -> Self {
        let mut s_actual = s_init;
        for modo in &gamma {
            s_actual = (s_actual + modo).rem_euclid(13);
        }
        Trayectoria {
            s_init,
            s_final: s_actual,
            gamma,
            pruebas,
        }
    }
}

pub fn distancia_stark(xa: &Trayectoria, xb: &Trayectoria) -> i32 {
    let diff_s = (xa.s_final - xb.s_final).abs();
    let d_s = std::cmp::min(diff_s, 13 - diff_s);

    let mut d_gamma = 0;
    let max_len = max(xa.gamma.len(), xb.gamma.len());
    for i in 0..max_len {
        let m_a = if i < xa.gamma.len() { xa.gamma[i] } else { 0 };
        let m_b = if i < xb.gamma.len() { xb.gamma[i] } else { 0 };
        d_gamma += (m_a - m_b).abs();
    }

    let set_a: HashSet<_> = xa.pruebas.iter().collect();
    let set_b: HashSet<_> = xb.pruebas.iter().collect();
    let d_p = set_a.symmetric_difference(&set_b).count() as i32;

    d_s + d_gamma + d_p
}

pub fn operador_omega(x: &Trayectoria, commit_raiz: &str) -> i32 {
    if x.pruebas.contains(&commit_raiz.to_string()) {
        1
    } else {
        0
    }
}
