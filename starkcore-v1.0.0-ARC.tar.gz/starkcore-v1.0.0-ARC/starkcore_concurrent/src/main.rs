// src/main.rs
// Gramática de Trayectorias 13 — Simulación Concurrente Pulida
// Autor: Luis Alberto Burciaga Miker
// Ubicación: El Rosario / Ensenada, Baja California, México

use rayon::prelude::*;
use starkcore_concurrent::{Trayectoria, distancia_stark, operador_omega};

fn main() {
    let commit_raiz = "0a5df7415f92d330c77a90552bc61cf29faa96b3";

    // Conjunto distribuido de trayectorias genuinas independientes
    let trayectorias: Vec<Trayectoria> = vec![
        Trayectoria::new(2, vec![1, 1, 1, 0], vec![commit_raiz.to_string(), "d43c574".to_string()]),
        Trayectoria::new(4, vec![1, -1, 0, 1], vec![commit_raiz.to_string(), "e12fabc".to_string()]),
        Trayectoria::new(7, vec![0, 0, 1, 1], vec![commit_raiz.to_string(), "f98d321".to_string()]),
    ];

    // Configuración intrusa: Ruptura causal forzada (Ω -> 0)
    let intruso = Trayectoria::new(
        2,
        vec![1, 1, 1, 0],
        vec!["commit_falso_inyectado".to_string(), "d43c574".to_string()],
    );

    println!("=======================================================");
    println!("=== STARKCORE SIMULACIÓN CONCURRENTE (RAYON ENGINE) ===");
    println!("=======================================================");

    println!("\n[Fase 1: Evaluación paralela del operador Ω]");
    trayectorias.par_iter().for_each(|x| {
        let omega = operador_omega(x, commit_raiz);
        println!("  -> Ω(Trayectoria init_s: {}, final_s: {}) = {} (Verificación: OK)", x.s_init, x.s_final, omega);
    });

    println!("\n[Fase 2: Cálculo simultáneo de distancias métricas d_Stark contra Intruso]");
    trayectorias.par_iter().for_each(|x| {
        let d = distancia_stark(x, &intruso);
        println!("  -> d_Stark(Origen s_init: {} -> s_final: {}, Intruso) = {} [Pasos Evaluados]", x.s_init, x.s_final, d);
    });

    println!("\nConclusión: El espacio concurrente mantiene consistencia métrica y detecta rupturas en paralelo sin colisiones en el hilo.");
}
