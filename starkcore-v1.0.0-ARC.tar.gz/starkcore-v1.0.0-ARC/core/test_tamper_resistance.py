import json, hashlib, subprocess
from pathlib import Path

print("=== TEST 1: alterar un solo campo dist ===")
content = Path("evidence/telemetry_live.jsonl").read_bytes()
# Ataca el byte real, no el char unicode
# Busca b'1200' y cambialo por b'1201' en la primera ocurrencia
tampered = content.replace(b"1200", b"1201", 1)
Path("/tmp/tampered.jsonl").write_bytes(tampered)

h1 = hashlib.sha256(content).hexdigest()
h2 = hashlib.sha256(tampered).hexdigest()
print(f"original:  {h1}")
print(f"tampered:  {h2}")
print(f"match={h1==h2}")
assert h1 != h2, "hash deberia cambiar"
print("✅ DETECTADO: 1 digito cambia hash\n")

print("=== TEST 2: commit binding ===")
manifest = json.loads(Path("evidence/telemetry_manifest.json").read_text())
real_commit = subprocess.check_output("git rev-parse HEAD", shell=True, text=True).strip()
print(f"manifest: {manifest['commit_short']} HEAD: {real_commit[:7]} match={manifest['commit']==real_commit}")

print("\n=== TEST 3: env honesto ===")
manifest["environment"]["rustc"] = subprocess.check_output("rustc --version 2>&1 || echo 'no rustc - python hackmode'", shell=True, text=True).strip()
Path("evidence/telemetry_manifest.json").write_text(json.dumps(manifest, indent=2))
print("manifest honesto OK")
print("\nCONCLUSION: 1 byte -> hash distinto -> FAIL")
