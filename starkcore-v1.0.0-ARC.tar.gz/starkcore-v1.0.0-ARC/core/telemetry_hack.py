import time, random, json
from pathlib import Path

LOG = Path("evidence/telemetry_live.jsonl")
LOG.parent.mkdir(exist_ok=True)

STATS = {"total":0, "pass":0, "drop_div":0, "drop_geom":0}

def evento(ts=None, pkt_len=None, div=None):
    div = div if div else random.choice([2,4,6,8])
    pkt_len = pkt_len if pkt_len else random.choice([64,128])
    dist = 18400 if div < 5 else 1200
    if div < 3:
        reason="low_div"; action="DROP"; STATS["drop_div"]+=1
    elif dist > 15000:
        reason="geom"; action="DROP"; STATS["drop_geom"]+=1
    else:
        reason="ok"; action="PASS"; STATS["pass"]+=1
    STATS["total"]+=1
    
    log = f"[{time.time_ns()}] {action} reason={reason} len={pkt_len} div={div} dist²={dist} anchor=8447a3e2 A11=f8581c6f U=31977997"
    print(log)
    with open(LOG,"a") as f:
        f.write(json.dumps({"log":log, "S_U":"3197f997","anchor":"8447a3e2"})+"\n")
    
    if STATS["total"] % 10 == 0:
        print(f"--- STATS total={STATS['total']} pass={STATS['pass']} drop_div={STATS['drop_div']} drop_geom={STATS['drop_geom']} ---")
    return action

if __name__ == "__main__":
    print("[+] ghostcore HACK MODE - telemetria simulada RingBuf 256KB")
    while True:
        evento()
        time.sleep(0.2)
