import hashlib, json, time
root = "3b1a7de5d466b5cd96ed08ade1b52b0f8cf9214df0cd8247c696cd78f6eb39af"
block_hash = "00007ad4cb74402481c7b90e6a86f70d1d508672bc6102f4fa0570116702111b"
nonce = 39317

cert = {
  "project": "StarkCore CA-002/CA-003",
  "merkle_root": root,
  "block_hash": block_hash,
  "nonce": nonce,
  "target": "0000ffff...",
  "txs": ['CA-002 firewall check', 'CA-003 mitigation', 'package-lock sha a59f1ed0e1cc19', 'StarkCore proof'],
  "timestamp": int(time.time()),
  "anchored": "regtest + ready for mainnet OTS"
}
open("starkcore-proof.json","w").write(json.dumps(cert, indent=2))
print(open("starkcore-proof.json").read())
print("\n--- PARA ANCLAR EN BITCOIN MAINNET GRATIS ---")
print(f"echo -n {root} | sha256sum")
print(f"Luego ve a https://opentimestamps.org y pega: {root}")
