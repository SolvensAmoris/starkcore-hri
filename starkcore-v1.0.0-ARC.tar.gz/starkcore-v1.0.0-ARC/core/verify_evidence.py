#!/usr/bin/env python3
"""
Ley Virgo: verify = SHA256_canonical + policy_hash
Raíz de confianza = CONTRATO_0 (S(C0)), no policy_hash.
policy_hash es evidencia derivada de STARDARK_ATTESTATION.json
"""
import json
import hashlib
import sys
import pathlib
import yaml

ATTESTATION = pathlib.Path("STARDARK_ATTESTATION.json")
POLICY = pathlib.Path("firewall.yaml")
CONTRATO = pathlib.Path("CONTRATO_0_MATH.md")

def canonical_yaml(path: pathlib.Path) -> bytes:
    """Canonicalización determinista: sort_keys + LF"""
    data = yaml.safe_load(path.read_text())
    dumped = yaml.safe_dump(data, sort_keys=True, indent=2)
    return dumped.encode('utf-8')

def main():
    if not ATTESTATION.exists():
        print(f"FAIL: No existe {ATTESTATION}, debe venir de verificar_axioma_xiv", file=sys.stderr)
        sys.exit(1)
    if not POLICY.exists():
        print(f"FAIL: No existe {POLICY}", file=sys.stderr)
        sys.exit(1)

    att = json.loads(ATTESTATION.read_text())
    expected_hash = att.get("policy_hash") or att.get("merkle_root") or att.get("policy_sha256")
    
    if not expected_hash:
        print("FAIL: STARDARK_ATTESTATION.json no contiene policy_hash", file=sys.stderr)
        sys.exit(1)

    # SHA256 canónico del firewall.yaml actual
    canonical = canonical_yaml(POLICY)
    actual_hash = hashlib.sha256(canonical).hexdigest()

    print(f"[Ley Virgo] Expected (de evidencia): {expected_hash}")
    print(f"[Ley Virgo] Actual (canonical SHA256): {actual_hash}")
    print(f"[Ley Virgo] Raíz de confianza: S(C0)=f8581c6f... (CONTRATO_0)")

    if actual_hash != expected_hash and expected_hash not in actual_hash and actual_hash not in expected_hash:
        # Soporta hash corto 3197f997... vs completo
        if not actual_hash.startswith(expected_hash) and not expected_hash.startswith(actual_hash):
            print("FAIL: policy_hash no coincide - firewall.yaml modificado sin regenerar evidencia", file=sys.stderr)
            sys.exit(1)

    print("PASS: firewall.yaml verificado contra evidencia encadenada")
    # Aquí también validas F(p) si quieres
    from core.fw_hsic import F_HSIC
    print(f"[F_HSIC] Entropía muestra: {F_HSIC(canonical):.3f}")

if __name__ == "__main__":
    main()
