from setuptools import setup, find_packages
setup(
    name="starkcore-kernel",
    version="1.2.0",  # tu spec frozen 670211d
    packages=find_packages(),
    install_requires=[],
    description="Kernel inmutable S9/S10 + Mirror Gate P1-P4 + v24 Merkle + v25 Poseidon",
)
