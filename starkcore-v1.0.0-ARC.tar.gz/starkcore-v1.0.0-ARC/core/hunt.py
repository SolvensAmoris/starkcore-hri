import requests
# Ahora si funciona
print("=== HACKERONE BOUNTIES $100-$1000 ===")
programs = [
    ("gitlab", "https://gitlab.com/users/sign_in?redirect_to=//google.com", "$100-$1000"),
    ("shopify", "https://accounts.shopify.com/login?return_to=//google.com", "$500"),
    ("wolt", "https://wolt.com/oauth/authorize?client_id=...&redirect_uri=//google.com", "$100"),
    ("brave", "https://account.brave.com/login?redirect=//google.com", "$100-$250"),
    ("nextjs", "https://vercel.com/login?next=//google.com", "$150"),
]
for name, payload, bounty in programs:
    print(f"{name:10} {bounty:12} {payload}")

print("\nPrueba GitLab primero - es el que paga mas rapido en tu rango.")
