import hashlib, time

def sha256d(s):
    return hashlib.sha256(hashlib.sha256(s).digest()).digest()

def merkle_root(txs):
    hashes = [hashlib.sha256(hashlib.sha256(tx.encode()).digest()).digest() for tx in txs]
    while len(hashes) > 1:
        if len(hashes) % 2 == 1:
            hashes.append(hashes[-1])
        hashes = [sha256d(hashes[i] + hashes[i+1]) for i in range(0, len(hashes), 2)]
    return hashes[0].hex()

# Tus 4 archivos de CA-002
txs = [
    "CA-002 firewall check",
    "CA-003 mitigation",
    "package-lock sha a59f1ed0e1cc19",
    "StarkCore proof"
]

root = merkle_root(txs)
print(f"Merkle Root: {root}")
print(f"TXs: {txs}")

# Minado simple regtest-like (dificultad baja para tu CPU)
target = "0000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
nonce = 0
header_base = root
start = time.time()
while True:
    h = sha256d((header_base + str(nonce)).encode()).hex()
    if h < target:
        print(f"\n¡BLOQUE MINADO!")
        print(f"Nonce: {nonce}")
        print(f"Block Hash: {h}")
        print(f"Tiempo: {time.time()-start:.2f}s")
        break
    nonce += 1
    if nonce % 50000 == 0:
        print(f"intentando... {nonce} hashes")
