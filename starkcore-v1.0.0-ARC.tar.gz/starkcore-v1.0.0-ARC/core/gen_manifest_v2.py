import json, platform, sys
from pathlib import Path
manifest = json.loads(Path("evidence/telemetry_manifest.json").read_text())
manifest["environment"] = {
    "python": sys.version,
    "platform": platform.platform(),
    "arch": platform.machine(),
    "env": "UserLAnd Android - hackmode",
    "rustc": "nightly (simulado por compatibilidad)"
}
Path("evidence/telemetry_manifest.json").write_text(json.dumps(manifest, indent=2))
print("manifest + environment OK")
