import hashlib, json, subprocess, time
from pathlib import Path
from datetime import datetime, timezone

evidence_file = Path("evidence/telemetry_live.jsonl")
config_file = Path("core/telemetry_hack.py")

def sha256(p: Path):
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()

def git(cmd):
    return subprocess.check_output(cmd, shell=True, text=True).strip()

commit = git("git rev-parse HEAD")
branch = git("git rev-parse --abbrev-ref HEAD")
decision_count = len(evidence_file.read_text().splitlines()) if evidence_file.exists() else 0

# parse stats from jsonl quick
pass_n = drop_n = 0
for line in evidence_file.read_text().splitlines():
    if '"PASS' in line or 'PASS reason' in line:
        pass_n += 1
    if 'DROP' in line:
        drop_n += 1

manifest = {
    "engine_version": "0.2.0-hackmode",
    "engine": "ghostcore / starkcore",
    "commit": commit,
    "commit_short": commit[:7],
    "branch": branch,
    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    "telemetry_file": str(evidence_file),
    "telemetry_hash_sha256": sha256(evidence_file) if evidence_file.exists() else None,
    "telemetry_hash_blake3": None,
    "config_file": str(config_file),
    "config_hash_sha256": sha256(config_file) if config_file.exists() else None,
    "config_params": {
        "mu_escalado": [5000, 10000],
        "inv_cov_escalada": [1000, 0, 0, 1000],
        "umbral_distancia_cuadrado": 15000,
        "diversidad_minima": 3,
        "ringbuf_size_kb": 256,
        "anchor": "8447a3e2",
        "A11": "f8581c6f",
        "U_ref": "31977997"
    },
    "results": {
        "decision_count": decision_count,
        "pass": pass_n,
        "drop": drop_n,
        "drop_div": "low_div",
        "drop_geom": "geom"
    },
    "repro": "python3 core/telemetry_hack.py > evidence/telemetry_live.jsonl",
    "verifiable_claim": "Cada decision incluye ts, reason, len, div, dist², anchor, A11, U_ref - trazable y reproducible"
}

Path("evidence/telemetry_manifest.json").write_text(json.dumps(manifest, indent=2))
print(json.dumps(manifest, indent=2))
