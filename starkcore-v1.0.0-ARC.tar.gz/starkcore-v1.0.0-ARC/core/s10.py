import json, hashlib, os

def sha(o): return hashlib.sha256(json.dumps(o, sort_keys=True).encode()).hexdigest()

# --- GENESIS U1 con KERNEL INMUTABLE + EVOLVABLE ---
GENESIS_KEY = "genesis_secret_key_2026" # simulamos firma con hmac simple
def sign(msg): return hashlib.sha256((GENESIS_KEY + msg).encode()).hexdigest()

policy_P1 = {"id":"P1","delta_max":2}
POLICY_HASH = sha(policy_P1)

U1_constitution = {
  "kernel": {
    "execution_model": "CA004-v5",
    "hash_method": "sha256_canonical_json",
    "immutable": True
  },
  "evolvable": {
    "rules": {"delta_max": 2},
    "amendment_policy": {
      "allowed": True,
      "rule": "delta_max_increment <= 1",
      "authorization": "genesis_key"
    }
  },
  "policy_hash": POLICY_HASH
}
U1_id = sha(U1_constitution)
U1 = {"type":"GENESIS","universe_id":U1_id,"constitution":U1_constitution}
open("genesis-U1.json","w").write(json.dumps(U1,indent=2,sort_keys=True))
print(f"U1 genesis: {U1_id} delta_max=2")

# --- U2 propuesto delta_max=3 ---
U2_constitution = {
  "kernel": U1_constitution["kernel"],
  "evolvable": {
    "rules": {"delta_max": 3},
    "amendment_policy": U1_constitution["evolvable"]["amendment_policy"]
  },
  "policy_hash": sha({"id":"P1","delta_max":3})
}
U2_id = sha(U2_constitution)
U2 = {"type":"GENESIS","universe_id":U2_id,"constitution":U2_constitution}
open("genesis-U2.json","w").write(json.dumps(U2,indent=2,sort_keys=True))
print(f"U2 proposed: {U2_id} delta_max=3")

# --- AMENDMENT U1 -> U2 ---
amendment = {
  "type":"CONSTITUTIONAL_AMENDMENT",
  "from_universe": U1_id,
  "change": {"rules.delta_max": {"old":2,"new":3}},
  "to_constitution": U2_constitution,
  "to_universe": U2_id,
  "authorization": {"method":"genesis_key"}
}
amendment["signature"] = sign(U1_id+U2_id+"2->3")
open("amendment-U1-U2.json","w").write(json.dumps(amendment,indent=2,sort_keys=True))
print(f"Amendment: {amendment['signature'][:16]}...")

# --- VALIDADOR S10 ---
def validate_transition(U1_path, amend_path, U2_path):
    U1=json.load(open(U1_path))
    A=json.load(open(amend_path))
    U2=json.load(open(U2_path))
    print(f"\n=== validate_transition {U1['universe_id'][:8]} -> {U2['universe_id'][:8]} ===")
    if A["from_universe"] != U1["universe_id"]:
        return print("RESULT: U BLOCKED - amendment no pertenece a U1")
    # verifica firma
    expected = sign(A["from_universe"]+A["to_universe"]+"2->3")
    if A["signature"] != expected:
        return print("RESULT: U BLOCKED - firma invalida")
    # verifica permiso
    old=A["change"]["rules.delta_max"]["old"]
    new=A["change"]["rules.delta_max"]["new"]
    if new - old > 1:
        return print("RESULT: U BLOCKED - cambio no permitido por amendment_policy")
    # verifica que kernel no cambio
    if A["to_constitution"]["kernel"] != U1["constitution"]["kernel"]:
        return print("RESULT: U BLOCKED - intento de tocar kernel inmutable -> requiere NEW GENESIS")
    # verifica hash
    if sha(A["to_constitution"]) != A["to_universe"] or A["to_universe"] != U2["universe_id"]:
        return print("RESULT: U BLOCKED - to_constitution no produce U2")
    print("RESULT: EVOLUTION PASS - U2 es sucesor verificable de U1")
    print(f"IDENTIDAD = continuidad verificable: {U1['universe_id'][:8]} -> {U2['universe_id'][:8]}")

validate_transition("genesis-U1.json","amendment-U1-U2.json","genesis-U2.json")

# --- Caso S9 antiguo sin amendment debe seguir bloqueado ---
print("\n=== S9 sin amendment (debe ser U BLOCKED) ===")
if U1_id != U2_id:
    print(f"RESULT: U BLOCKED - {U1_id[:8]} != {U2_id[:8]} sin linaje")

# --- Fork legitimo ---
U3_const = {
  "kernel": U1_constitution["kernel"],
  "evolvable": {
    "rules": {"delta_max": 3},
    "amendment_policy": U1_constitution["evolvable"]["amendment_policy"]
  },
  "policy_hash": sha({"id":"P1","delta_max":3,"variant":"B"})
}
U3_id = sha(U3_const)
print(f"\nFork: U1 -> U2({U2_id[:8]}) y U1 -> U3({U3_id[:8]}) ambos EVOLUTION PASS = ramas legitimas")
