import hashlib
import math
from collections import Counter

def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = Counter(data)
    length = len(data)
    return -sum((c/length) * math.log2(c/length) for c in counts.values())

def F_HSIC(payload: bytes) -> float:
    """Tu firewall matemático: H(payload)"""
    return shannon_entropy(payload)

def test_mode():
    # Test rápido para CI
    assert F_HSIC(b"AAAA") < 1.0
    assert F_HSIC(b"GET / HTTP/1.1") > 2.0
    print("[FW_HSIC] PASS")
