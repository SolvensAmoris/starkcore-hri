import hashlib, json
def S(d): return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()
def merkle_root(leaves):
    if not leaves: return "0"*64
    layer = leaves[:]
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i+1] if i+1 < len(layer) else a
            nxt.append(S(a+b))
        layer = nxt
    return layer[0]
def merkle_proof(leaves, index):
    proof = []
    layer = leaves[:]
    idx = index
    while len(layer) > 1:
        pair = idx ^ 1
        if pair < len(layer):
            proof.append(layer[pair])
        else:
            proof.append(layer[idx])
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i+1] if i+1 < len(layer) else a
            nxt.append(S(a+b))
        layer = nxt
        idx //= 2
    return proof
logs = ["ad5a2d", "bb3f99", "46a3ff"]
root = merkle_root(logs)
proof = merkle_proof(logs, 0)
print(f"Finality log: {logs}")
print(f"Merkle root: {root[:16]}...")
print(f"Proof para ad5a2d: {proof}")
print(f"V24 PASS: compresion logaritmica")
