import hashlib
import subprocess
from pathlib import Path
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse

app = FastAPI(title="StarkCore REAL")

BASE_DIR = Path(__file__).parent.resolve()
ALLOWED_ROOTS = [BASE_DIR / "core", BASE_DIR / "tests", BASE_DIR] # solo deja leer de aquí

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def get_commit() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=BASE_DIR, timeout=2).decode().strip()
    except Exception:
        return ""

def safe_resolve(requested: str) -> Path:
    # Previene../../../etc/passwd
    if not requested:
        raise HTTPException(status_code=400, detail="file param required")
    # normaliza y quita.. al inicio
    clean = requested.strip().lstrip("/")
    target = (BASE_DIR / clean).resolve()
    # debe estar dentro de BASE_DIR
    if not str(target).startswith(str(BASE_DIR)):
        raise HTTPException(status_code=403, detail="path traversal blocked")
    # debe estar dentro de ALLOWED_ROOTS y existir
    if not any(str(target).startswith(str(r.resolve())) for r in ALLOWED_ROOTS):
        raise HTTPException(status_code=403, detail="outside allowed roots")
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"file not found: {requested}")
    return target

@app.get("/")
def root():
    return {"status": "StarkCore REAL - lee disco, no inventa"}

@app.get("/audit")
def audit():
    files_to_audit = ["core/v24_merkle.py", "core/v25_poseidon.py", "tests/contracts/test_contract_mirror_gate_p1_p2.py"]
    hashes = {}
    for rel in files_to_audit:
        p = BASE_DIR / rel
        if p.exists():
            hashes[rel] = sha256_file(p)
        else:
            hashes[rel] = "missing"

    # merkle root REAL = hash de todos los hashes concatenados ordenados
    concat = "".join(hashes[k] for k in sorted(hashes))
    merkle_root = hashlib.sha256(concat.encode()).hexdigest()

    return {
        "frozen_commit": get_commit(),
        "merkle_root_REAL": merkle_root,
        "evidence_files_hashes": hashes,
        "verifiable_with": "curl -s http://127.0.0.1:8000/verify?file=core/v24_merkle.py | python3 -c \"import sys,json,hashlib; d=json.load(sys.stdin); print(hashlib.sha256(d['file_content'].encode()).hexdigest())\"",
        "is_hardcoded": False
    }

@app.get("/verify")
def verify(file: str = Query(..., description="ej: core/v24_merkle.py")):
    target = safe_resolve(file)
    content_text = target.read_text(encoding="utf-8", errors="ignore")
    file_hash = sha256_file(target)

    return {
        "requested_file": file,
        "resolved_path": str(target.relative_to(BASE_DIR)),
        "sha256": file_hash,
        "file_content": content_text,
        "size_bytes": target.stat().st_size,
        "verify_cmd": f"curl -s http://127.0.0.1:8000/verify?file={file} | jq -r.file_content | sha256sum"
    }
