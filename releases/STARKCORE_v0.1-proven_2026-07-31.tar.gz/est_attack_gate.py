from cosmos.security.seed_channel import SeedChannel, CA002
from cosmos.dag import AttestedDAG

print("===== CA002 ATTACK GATE =====")

channel = SeedChannel()

seed = channel.from_hex(
    "A7F39211",
    name="starkcore_root"
)

real_hash = channel.identity_hash(seed)

print("REAL HASH:", real_hash[:32])

dag = AttestedDAG()

dag.add_node(
    "attack_node",
    metadata={
        "ast_node": seed
    }
)

print("\n[ATTACK] Inject fake identity hash")

fake_hash = "0000000000000000000000000000000000000000000000000000000000000000"

try:
    dag.attest(
        seed_channel=channel,
        published_hashes={
            "attack_node": fake_hash
        }
    )

    print("ERROR: ATTACK PASSED")

except CA002 as e:
    print("CA002 BLOCKED:")
    print(e)

print("\n===== END ATTACK TEST =====")
