from cosmos.security.seed_channel import SeedChannel, CA002
from cosmos.dag import AttestedDAG
from cosmos.compiler.validators.temporal import verify_temporal_restrictions


print("===== STARKCORE FULL GATE TEST =====")


# 1. CHANNEL 7
print("\n[1] CHANNEL 7 IDENTITY")

channel = SeedChannel()

seed = channel.from_hex(
    "A7F39211",
    name="starkcore_root"
)

identity = channel.identity_hash(seed)

print("Seed hash:", identity[:32])


# 2. ATTESTED DAG
print("\n[2] ATTESTED DAG")

dag = AttestedDAG()

dag.add_node(
    "light_flow",
    metadata={
        "ast_node": seed
    }
)

try:
    attest = dag.attest(
        seed_channel=channel,
        published_hashes={
            "light_flow": identity
        }
    )

    print("Attestation:", attest)

except CA002 as e:
    print("BLOCKED CA002:", e)
    raise SystemExit


# 3. TEMPORAL POLICY
print("\n[3] TEMPORAL POLICY")


expired_policy = {
    "lights": [
        {
            "restringido_hasta": "2025-01-01",
            "from": "SUN",
            "to": "NODE"
        }
    ]
}


errors = verify_temporal_restrictions(expired_policy)


if errors:
    print("TEMPORAL BLOCK:")
    for err in errors:
        print(
            f"{err.code} | {err.severity} | {err.message}"
        )

    print("\nSCHEDULER: BLOCKED")
    print("EXECUTION: DENIED")

else:
    print("TEMPORAL OK")
    print("SCHEDULER: ALLOWED")


print("\n===== END TEST =====")
