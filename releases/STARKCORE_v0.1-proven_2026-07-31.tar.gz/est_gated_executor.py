from cosmos.security.seed_channel import SeedChannel, CA002
from cosmos.runtime.gated_executor import GatedCosmosExecutor

channel = SeedChannel()
executor = GatedCosmosExecutor(channel)

# 1. Deploy legítimo
seed = channel.from_hex("A7F39211", name="starkcore_root")
executor.publish("light_flow", seed)

print("[TEST 1] Ejecución legítima")
try:
    executor.execute("light_flow", seed, {"lights": [{"restringido_hasta": "2027-01-01", "from": "SUN", "to": "NODE"}]})
    print("-> ALLOWED ✅")
except Exception as e:
    print(f"-> BLOCKED {e}")

print("\n[TEST 2] Mutación de artefacto (ataque)")
mutated = channel.from_hex("B81210F2", name="starkcore_root") # cambia bytes
try:
    executor.execute("light_flow", mutated)
    print("-> ALLOWED ❌ VULNERABLE")
except CA002 as e:
    print(f"-> {e}")

print("\n[TEST 3] Política temporal expirada")
try:
    executor.execute("light_flow", seed, {"lights": [{"restringido_hasta": "2025-01-01", "from": "SUN", "to": "NODE"}]})
    print("-> ALLOWED ❌ VULNERABLE")
except Exception as e:
    print(f"-> BLOCKED {e.code} | {e.message}")

print("\n===== GATED EXECUTOR VERIFIED =====")
