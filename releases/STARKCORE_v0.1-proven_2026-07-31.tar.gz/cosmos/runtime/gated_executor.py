from cosmos.security.seed_channel import SeedChannel, CA002

class E401Block(Exception):
    def __init__(self, compile_error):
        self.code = compile_error.code
        self.message = compile_error.message
        super().__init__(f"{compile_error.code} | {compile_error.severity} | {compile_error.message}")

class GatedCosmosExecutor:
    def __init__(self, seed_channel: SeedChannel):
        self.channel = seed_channel
        self.published_hashes = {}

    def publish(self, node_id: str, seed):
        self.published_hashes[node_id] = self.channel.identity_hash(seed)

    def execute(self, node_id: str, seed, lights_policy=None):
        from cosmos.compiler.validators.temporal import verify_temporal_restrictions

        expected = self.published_hashes.get(node_id)
        if expected is None:
            raise CA002(f"Unpublished node {node_id} - EXECUTION BLOCKED")

        real = self.channel.identity_hash(seed)
        if expected!= real:
            raise CA002(
                f"EXECUTION BLOCKED | Seed mismatch expected={expected[:32]} "
                f"real={real[:32]} | node={node_id}"
            )

        if lights_policy:
            errors = verify_temporal_restrictions(lights_policy)
            if errors:
                raise E401Block(errors[0])

        print(f"EXECUTING {node_id} -> {seed.tokens}")
        return True
