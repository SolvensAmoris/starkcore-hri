import hashlib
import json
from datetime import datetime

from cosmos.security.seed_channel import SeedChannel
from cosmos.dag import AttestedDAG


print("===== STARKCORE PROVENANCE RECORD =====")

channel = SeedChannel()

seed = channel.from_hex(
    "A7F39211",
    name="starkcore_root"
)

identity_hash = channel.identity_hash(seed)

dag = AttestedDAG()

dag.add_node(
    "root_flow",
    metadata={
        "ast_node": seed,
        "channel": "7",
        "policy": "CA002"
    }
)

attested = dag.attest(
    seed_channel=channel,
    published_hashes={
        "root_flow": identity_hash
    }
)

record = {
    "timestamp": datetime.utcnow().isoformat(),
    "seed_identity": identity_hash,
    "channel": "7",
    "attested": attested,
    "nodes": list(dag.nodes.keys()),
    "verification": "PASS"
}

canonical = json.dumps(
    record,
    sort_keys=True
)

record_hash = hashlib.sha256(
    canonical.encode()
).hexdigest()


print(json.dumps(record, indent=2))
print("\nEVIDENCE HASH:")
print(record_hash)

print("\nSTATUS: VERIFIED")
