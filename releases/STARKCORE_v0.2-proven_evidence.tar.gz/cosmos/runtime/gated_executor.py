from.evidence_store import EvidenceStore
from datetime import datetime

try:
    from..dag import AttestedDAGError
except:
    class AttestedDAGError(Exception):
        def __init__(self, msg, code="UNKNOWN"):
            super().__init__(msg)
            self.code = code

class _FallbackValidator:
    def validate(self, light):
        class R:
            def __init__(self, ok): self.ok=ok
        limit = light.get("restringido_hasta")
        if not limit: return R(True)
        try:
            lim = datetime.fromisoformat(limit).date()
            ref = datetime(2026,7,13).date()
            return R(lim >= ref)
        except:
            return R(False)

class GatedCosmosExecutor:
    def __init__(self, channel, evidence_path="/tmp/starkcore_evidence.jsonl"):
        self.channel = channel
        self.published = {}
        self.evidence = EvidenceStore(evidence_path)
        self.validator = _FallbackValidator()
        # intentar cargar real si existe con otro nombre
        try:
            import cosmos.compiler.validators.temporal as tv
            if hasattr(tv, 'TemporalValidator'):
                self.validator = tv.TemporalValidator()
            elif hasattr(tv, 'validate'):
                # adaptar funcion a clase
                func = tv.validate
                class Adapt:
                    def validate(self, light):
                        ok = func(light)
                        class R:
                            def __init__(self, o): self.ok = bool(o) if not hasattr(o,'ok') else o.ok
                        return R(ok)
                self.validator = Adapt()
        except Exception as e:
            print(f"[INFO] usando fallback validator: {e}")

    def _tokens_str(self, seed_decl):
        try:
            toks = seed_decl.tokens
            # puede ser [str] o [Token.value]
            out=[]
            for t in toks:
                out.append(t.value if hasattr(t,'value') else str(t))
            return out
        except:
            return [str(seed_decl)]

    def publish(self, node_id, seed_decl):
        h = self.channel.identity_hash(seed_decl)
        self.published[node_id] = h
        self.evidence.append(node_id=node_id, identity_hash=h, attestation_result="PUBLISH", temporal_result="NOT_CHECKED", execution_decision="PUBLISHED")
        return h

    def execute(self, node_id, seed_decl, dag_data=None):
        real = self.channel.identity_hash(seed_decl)
        expected = self.published.get(node_id)

        if expected is None:
            self.evidence.append(node_id=node_id, identity_hash=real, attestation_result="FAIL", temporal_result="NOT_CHECKED", execution_decision="DENIED_UNPUBLISHED", error_code="CA002")
            raise AttestedDAGError(f"CA002 UNPUBLISHED: {node_id}", code="CA002")
        if real!= expected:
            self.evidence.append(node_id=node_id, identity_hash=real, attestation_result="FAIL", temporal_result="NOT_CHECKED", execution_decision="DENIED_CA002", error_code="CA002", extra={"expected": expected})
            raise AttestedDAGError(f"CA002 BLOCKED: Seed mismatch expected={expected} real={real}", code="CA002")

        if dag_data and "lights" in dag_data:
            for light in dag_data["lights"]:
                result = self.validator.validate(light)
                ok = result.ok if hasattr(result,'ok') else bool(result)
                if not ok:
                    self.evidence.append(node_id=node_id, identity_hash=real, attestation_result="PASS", temporal_result="E401_BLOCK", execution_decision="DENIED_E401", error_code="E401", extra={"light": light})
                    raise AttestedDAGError(f"E401 | REJECT | Flow validity period has expired. Limit was {light.get('restringido_hasta')}", code="E401")

        print(f"EXECUTING {node_id} -> {self._tokens_str(seed_decl)}")
        self.evidence.append(node_id=node_id, identity_hash=real, attestation_result="PASS", temporal_result="PASS", execution_decision="ALLOWED")
        return True
