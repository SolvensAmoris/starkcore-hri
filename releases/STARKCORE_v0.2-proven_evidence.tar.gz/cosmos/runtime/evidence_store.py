import json, hashlib, os
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

class EvidenceStore:
    """
    Append-only JSONL evidence for StarkCore
    Chain: IDENTIDAD -> EVIDENCIA -> VALIDACION -> ADMISION -> EJECUCION
    """
    def __init__(self, path: str = "/tmp/starkcore_evidence.jsonl"):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        # crear si no existe
        if not os.path.exists(self.path):
            open(self.path, "w").close()

    def _canonical_hash(self, record: Dict[str, Any]) -> str:
        # hash del contenido sin evidence_hash ni timestamp para estabilidad,
        # pero incluimos timestamp en el hash final para trazabilidad total
        # Requisito 3: SHA256 del contenido canónico
        canonical = json.dumps(record, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
        return hashlib.sha256(canonical.encode('utf-8')).hexdigest()

    def append(self, *, node_id: str, identity_hash: str, attestation_result: str,
               temporal_result: str, execution_decision: str, error_code: Optional[str] = None,
               extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:

        base_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "node_id": node_id,
            "identity_hash": identity_hash,
            "attestation_result": attestation_result, # PASS | FAIL | NOT_CHECKED
            "temporal_result": temporal_result, # PASS | E401_BLOCK | NOT_CHECKED
            "execution_decision": execution_decision, # ALLOWED | DENIED_CA002 | DENIED_E401 | DENIED_UNPUBLISHED
            "error_code": error_code,
        }
        if extra:
            base_record.update(extra)

        # hash canónico
        evidence_hash = self._canonical_hash(base_record)
        full_record = {**base_record, "evidence_hash": evidence_hash}

        # append-only, nunca modificar (req 4)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(full_record, ensure_ascii=False) + "\n")

        return full_record

    def read_all(self) -> List[Dict[str, Any]]:
        records = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line=line.strip()
                if line:
                    records.append(json.loads(line))
        return records

    def verify_chain(self) -> bool:
        # verifica que cada evidence_hash corresponde al contenido
        for rec in self.read_all():
            rec_copy = dict(rec)
            eh = rec_copy.pop("evidence_hash", None)
            if eh!= self._canonical_hash(rec_copy):
                return False
        return True

    def replay(self, node_id: str) -> List[Dict[str, Any]]:
        return [r for r in self.read_all() if r["node_id"] == node_id]
