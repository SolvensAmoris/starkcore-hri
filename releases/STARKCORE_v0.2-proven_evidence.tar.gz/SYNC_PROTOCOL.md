# STARKCORE SYNC PROTOCOL v1.0

## ROLE

Eres un agente colaborador dentro del ecosistema StarkCore.

Antes de modificar, analizar o proponer cambios debes sincronizar tu modelo mental con este estado del sistema.

No empieces arqueología del repositorio.
Primero entiende las invariantes.

---

# PROJECT STATE

PROJECT:
StarkCore / Solvens-Core

MISSION:
Construir una arquitectura donde la ejecución dependa de evidencia verificable.

CORE PRINCIPLE:

Una declaración no es una prueba.

Un estado es válido únicamente si existe un mecanismo reproducible para verificarlo.

---

# ARCHITECTURE MAP

## IDENTITY LAYER

Component:
Channel 7 / SeedChannel

Purpose:

Convertir una semilla en identidad estructural verificable.

Pipeline:

seed_bytes
↓
canonical_encode
↓
SeedDecl
↓
identity_hash SHA256

Invariant:

Si cambia el artefacto, debe cambiar la identidad.

Failure:

CA002 Identity Mutation


---

## GRAPH LAYER

Component:

AttestedDAG

Purpose:

Representar ejecución como un grafo verificable.

Rule:

Un nodo no atestado no puede avanzar al scheduler.

Verification:

identity_hash esperado
vs
identity_hash real


---

## POLICY LAYER

Component:

Temporal Validator

Purpose:

Validar restricciones temporales.

Failure:

E401 TemporalConstraintViolation

Behavior:

Política expirada = ejecución bloqueada.


---

## EXECUTION LAYER

Component:

GatedCosmosExecutor

Purpose:

Última frontera antes del runtime.

Execution order:

1. Verificar identidad
2. Verificar evidencia
3. Verificar políticas
4. Permitir ejecución


---

# VERIFIED STATE

Actualmente probado:

[PASS] Channel 7 identity generation

[PASS] SHA256 identity verification

[PASS] CA002 fake identity detection

[PASS] CA002 mutation detection

[PASS] AttestedDAG verification

[PASS] Temporal validator blocking

[PASS] Runtime admission gate

[PASS] Provenance evidence record


---

# CURRENT LIMITS

Pendiente:

- conexión con providers reales
- red real / HTTP routing
- firmas criptográficas completas
- persistencia de evidencia
- scheduler productivo
- benchmarks reales no simulados


---

# DEVELOPMENT RULES

Nunca:

- aceptar identidad mutable
- ejecutar antes de validar
- confundir scaffold con implementación
- sustituir evidencia por narrativa


Siempre:

- reproducir
- medir
- verificar
- documentar


---

# AGENT SYNC RESPONSE

Después de leer este documento responde:

SYNC_OK

Después entrega:

1. Modelo mental adquirido
2. Componentes comprendidos
3. Riesgos detectados
4. Próximo punto técnico recomendado


